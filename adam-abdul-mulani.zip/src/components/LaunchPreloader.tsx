import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, Shield, Radio, Flame, CheckCircle, Orbit, Zap } from 'lucide-react';

interface LaunchPreloaderProps {
  onComplete: () => void;
}

export default function LaunchPreloader({ onComplete }: LaunchPreloaderProps) {
  const [progress, setProgress] = useState(1);
  const [isMuted, setIsMuted] = useState(true);
  const [statusMessage, setStatusMessage] = useState('Initializing Systems');
  const [hudMessage, setHudMessage] = useState('SYSTEM CHECK OK');
  const [shaking, setShaking] = useState(false);
  const [ignited, setIgnited] = useState(false);
  const [launched, setLaunched] = useState(false);
  const [warpSpeed, setWarpSpeed] = useState(false);

  // Web Audio Context for Procedural Retro Sci-Fi SFX
  const audioContextRef = useRef<AudioContext | null>(null);
  const rumbleOscRef = useRef<OscillatorNode | null>(null);
  const rumbleGainRef = useRef<GainNode | null>(null);

  // Randomize total duration between 5.5 to 8.5 seconds
  const totalDuration = useRef(Math.floor(Math.random() * 3000) + 5500);

  // Initialize Web Audio API
  const initAudio = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
  };

  // Play procedural UI beep
  const playBeep = (freq = 880, duration = 0.05) => {
    if (isMuted) return;
    try {
      initAudio();
      const ctx = audioContextRef.current;
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.warn('Audio play failure:', e);
    }
  };

  // Start engine rumble procedural oscillator
  const startRumble = () => {
    if (isMuted) return;
    try {
      initAudio();
      const ctx = audioContextRef.current;
      if (!ctx) return;

      if (rumbleOscRef.current) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      // Low frequency rumble for the rocket engine
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(45, ctx.currentTime);
      
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(120, ctx.currentTime);

      gain.gain.setValueAtTime(0.02, ctx.currentTime);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      
      rumbleOscRef.current = osc;
      rumbleGainRef.current = gain;
    } catch (e) {
      console.warn(e);
    }
  };

  // Ramp engine roar intensity
  const scaleRumble = (volume: number, freq: number) => {
    if (isMuted || !rumbleGainRef.current || !rumbleOscRef.current || !audioContextRef.current) return;
    try {
      const ctx = audioContextRef.current;
      rumbleGainRef.current.gain.linearRampToValueAtTime(volume, ctx.currentTime + 0.15);
      rumbleOscRef.current.frequency.linearRampToValueAtTime(freq, ctx.currentTime + 0.2);
    } catch (e) {
      console.warn(e);
    }
  };

  // Stop rocket rumble completely
  const stopRumble = () => {
    try {
      if (rumbleOscRef.current) {
        rumbleOscRef.current.stop();
        rumbleOscRef.current.disconnect();
        rumbleOscRef.current = null;
      }
      if (rumbleGainRef.current) {
        rumbleGainRef.current.disconnect();
        rumbleGainRef.current = null;
      }
    } catch (e) {
      console.warn(e);
    }
  };

  // Play final wrap speed release sound effect
  const playLaunchSweep = () => {
    if (isMuted) return;
    try {
      initAudio();
      const ctx = audioContextRef.current;
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(100, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(2500, ctx.currentTime + 0.9);

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.95);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 1.0);
    } catch (e) {
      console.warn(e);
    }
  };

  // Handle mute toggles mid-session
  useEffect(() => {
    if (isMuted) {
      stopRumble();
    } else {
      if (progress >= 50 && progress < 100) {
        startRumble();
        scaleRumble(progress >= 60 ? 0.08 : 0.04, progress >= 60 ? 80 : 55);
      }
    }
    return () => {
      stopRumble();
    };
  }, [isMuted]);

  // Main Progression Sequence Loop
  useEffect(() => {
    const startTime = Date.now();
    const duration = totalDuration.current;

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const calcProgress = Math.min(100, Math.floor((elapsed / duration) * 100) + 1);
      
      setProgress(calcProgress);

      // Procedural HUD feedback frequency update sound
      if (calcProgress % 10 === 0 && calcProgress < 100) {
        if (calcProgress < 50) playBeep(720, 0.03);
        else playBeep(1100, 0.04);
      }

      // Progressive status texts & triggers
      if (calcProgress >= 1 && calcProgress < 15) {
        setStatusMessage('Initializing Systems');
        setHudMessage('GRID LINK CALIBRATION STATUS: ACTIVE');
      } else if (calcProgress >= 15 && calcProgress < 30) {
        setStatusMessage('Loading Portfolio Data');
        setHudMessage('TRANSMITTING CORE CREDENTIAL DATABASE');
      } else if (calcProgress >= 30 && calcProgress < 50) {
        setStatusMessage('Connecting AI Neural Modules');
        setHudMessage('REACHING SYNAPSE NETWORKS AT 1.2 GBPS');
      } else if (calcProgress >= 50 && calcProgress < 60) {
        setStatusMessage('Igniting Rocket Engines');
        setHudMessage('WARNING: CORES AT CRITICAL STAGES');
        if (!ignited) {
          setIgnited(true);
          setShaking(true);
          startRumble();
          // Engine ignition beep patterns
          playBeep(220, 0.2);
          setTimeout(() => playBeep(330, 0.15), 150);
        }
      } else if (calcProgress >= 60 && calcProgress < 70) {
        setStatusMessage('Launch Initiated');
        setHudMessage('DECOUPLING PLATFORM SUPPORTS');
        setLaunched(true);
        scaleRumble(0.06, 65);
      } else if (calcProgress >= 70 && calcProgress < 80) {
        setStatusMessage('Ascending - Breaking Atmosphere');
        setHudMessage('ELEVATION: 45,000M AND CLIMBING');
        scaleRumble(0.09, 85);
      } else if (calcProgress >= 80 && calcProgress < 90) {
        setStatusMessage('Breaking Outer Stratosphere');
        setHudMessage('ATMOSPHERIC FRICTION PEAK');
        scaleRumble(0.12, 110);
      } else if (calcProgress >= 90 && calcProgress < 100) {
        setStatusMessage('Entering Orbit Velocity');
        setHudMessage('WARP CAPACITORS AT MAX CHARGE');
        scaleRumble(0.07, 140);
      } else if (calcProgress === 100) {
        setStatusMessage('Welcome Aboard!');
        setHudMessage('MISSION SUCCESSFUL - TARGET LOCKED');
        setShaking(false);
        setWarpSpeed(true);
        stopRumble();
        playLaunchSweep();
        clearInterval(interval);

        // Allow 1.8 seconds delay to complete deep warp exit animation cleanly
        setTimeout(() => {
          onComplete();
        }, 1800);
      }
    }, 45);

    return () => {
      clearInterval(interval);
      stopRumble();
    };
  }, [onComplete]);

  // Format counter to 3 digit HUD style (e.g., 001, 045, 100)
  const formatPercentage = (num: number) => {
    return String(num).padStart(3, '0');
  };

  // Fine-tuned animation states for ultimate smoothness with Framer Motion springs and physics
  const rocketAnimation = warpSpeed
    ? { y: -1200, scale: 0.35, rotateY: 360, opacity: 0, filter: 'blur(3px)' }
    : launched
    ? {
        y: -180,
        scale: 0.85,
        x: [0, -1, 1, -1, 1, 0],
        transition: {
          y: { type: 'spring', stiffness: 35, damping: 12 },
          scale: { duration: 0.8 },
          x: { repeat: Infinity, duration: 0.08, ease: 'linear' }
        }
      }
    : ignited
    ? {
        y: [0, -1.5, 1.5, -1, 1, 0],
        x: [0, 1.5, -1.5, 1.5, -1.5, 0],
        scale: 1.0,
        transition: {
          y: { repeat: Infinity, duration: 0.06, ease: 'linear' },
          x: { repeat: Infinity, duration: 0.05, ease: 'linear' }
        }
      }
    : {
        y: [0, -8, 0],
        x: [0, 0.4, -0.4, 0],
        scale: 1.0,
        transition: {
          y: { repeat: Infinity, duration: 3.0, ease: "easeInOut" },
          x: { repeat: Infinity, duration: 4.5, ease: "easeInOut" }
        }
      };

  return (
    <div
      className={`fixed inset-0 z-100 flex flex-col items-center justify-between py-12 px-6 overflow-hidden transition-all duration-700 bg-slate-950`}
      id="space-preloader"
    >
      {/* 1. Futuristic space background & stars simulation */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {/* Dynamic moving grid floor under rocket */}
        <div 
          className={`absolute bottom-0 left-[-50%] right-[-50%] h-[35vh] bg-[linear-gradient(to_bottom,rgba(15,23,42,0)_10%,rgba(37,99,235,0.15))] border-t border-blue-500/20 [transform:rotateX(60deg)] origin-bottom transition-all duration-[2000ms] ${
            launched ? 'opacity-10 translate-y-24' : 'opacity-65'
          }`}
          style={{
            backgroundImage: 'radial-gradient(ellipse at center, transparent 20%, rgba(15,23,42,0.85) 105%), linear-gradient(to right, rgba(23,37,84,0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(23,37,84,0.1) 1px, transparent 1px)',
            backgroundSize: '100% 100%, 3rem 3rem, 3rem 3rem'
          }}
        />

        {/* Ambient star emitters */}
        <div className={`absolute inset-0 transition-all duration-[1200ms] ${warpSpeed ? 'scale-[2.5] opacity-30' : ''}`}>
          <div className="absolute w-[2px] h-[2px] bg-white rounded-full top-[10%] left-[15%] animate-pulse" />
          <div className="absolute w-[1.5px] h-[1.5px] bg-cyan-400 rounded-full top-[25%] left-[75%] animate-pulse" style={{ animationDelay: '0.5s' }} />
          <div className="absolute w-[2.5px] h-[2.5px] bg-blue-400 rounded-full top-[60%] left-[20%] animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute w-[2px] h-[2px] bg-white rounded-full top-[40%] left-[85%] animate-pulse" style={{ animationDelay: '1.5s' }} />
          <div className="absolute w-[1.5px] h-[1.5px] bg-purple-400 rounded-full top-[80%] left-[45%] animate-pulse" style={{ animationDelay: '2s' }} />
        </div>

        {/* Dynamic descending star particles simulating vertical motion on ascension */}
        {launched && !warpSpeed && (
          <div className="absolute inset-0" id="descending-atmosphere-particulates">
            {[...Array(15)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ y: -50, opacity: 0 }}
                animate={{ y: '110vh', opacity: [0, 0.8, 0] }}
                transition={{
                  duration: Math.random() * 1.5 + 0.6,
                  repeat: Infinity,
                  delay: Math.random() * 2,
                  ease: 'linear'
                }}
                className="absolute w-[1px] bg-gradient-to-b from-transparent via-cyan-400 to-white"
                style={{
                  height: `${Math.random() * 60 + 20}px`,
                  left: `${Math.random() * 100}%`,
                }}
              />
            ))}
          </div>
        )}

        {/* Space Speed Warp Lines on 100% SUCCESS */}
        {warpSpeed && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0.1, opacity: 0 }}
                animate={{ scale: 15, opacity: [0, 1, 0], strokeWidth: [1, 8, 1] }}
                transition={{ duration: 0.8, repeat: Infinity, delay: (i * 0.04), ease: 'easeOut' }}
                className="absolute border border-blue-500/20 rounded-full shadow-[0_0_15px_rgba(6,182,212,0.1)]"
                style={{
                  width: `${(i + 1) * 20}px`,
                  height: `${(i + 1) * 20}px`,
                }}
              />
            ))}
          </div>
        )}

        {/* Ambient background blur blobs */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[550px] bg-blue-600/10 dark:bg-cyan-500/10 rounded-full blur-[120px]" />
      </div>

      {/* HEADER SECTION (HUD Telemetry & Sounds Selector) */}
      <div className="w-full max-w-5xl flex items-center justify-between z-10 select-none">
        <div className="flex items-center gap-2">
          <Orbit className="text-cyan-400 animate-spin" size={20} style={{ animationDuration: '4s' }} />
          <div className="font-mono text-[10px] tracking-widest text-slate-400">
            <span className="text-cyan-400 font-bold block">MISSION ALPHA PORTFOLIO</span>
            <span>STATUS: {hudMessage}</span>
          </div>
        </div>

        {/* Sound toggle controls */}
        <button
          onClick={() => {
            setIsMuted(!isMuted);
            playBeep(980, 0.08);
          }}
          className={`p-2.5 rounded-lg border flex items-center gap-2 transition-all cursor-pointer ${
            !isMuted
              ? 'bg-cyan-500/15 border-cyan-400/40 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.15)] animate-pulse'
              : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-white'
          }`}
          aria-label="Sound status trigger"
          id="sound-control-preloader"
        >
          {!isMuted ? <Volume2 size={15} /> : <VolumeX size={15} />}
          <span className="font-mono text-[10px] tracking-widest hidden sm:inline uppercase">
            {!isMuted ? 'Telemetry Audio Active' : 'Enable System Audio'}
          </span>
        </button>
      </div>

      {/* ROCKET LAUNCH SPACE (Interactive CSS visual rocket) */}
      <div className="flex-1 flex flex-col justify-center items-center relative w-full max-w-xl z-10 my-8">
        
        {/* Cinematic Shaking & Translation node powered smoothly by Framer Motion springs */}
        <motion.div
          animate={rocketAnimation as any}
          className="flex flex-col items-center relative"
        >
          {/* Ground Dust/Gas clouds prior to atmospheric decoupling */}
          {ignited && !warpSpeed && (
            <div className="absolute bottom-[-15px] inset-x-[-120px] flex justify-center pointer-events-none">
              <div className="flex gap-2">
                <div className="w-16 h-16 bg-slate-100/10 dark:bg-slate-800/20 rounded-full blur-lg animate-[pulse_0.4s_infinite_alternate]" />
                <div className="w-24 h-24 bg-slate-100/15 dark:bg-cyan-500/10 rounded-full blur-xl animate-[pulse_0.3s_infinite_alternate] delay-75" />
                <div className="w-16 h-16 bg-slate-100/10 dark:bg-slate-800/20 rounded-full blur-lg animate-[pulse_0.4s_infinite_alternate] delay-150" />
              </div>
            </div>
          )}

          {/* Aerodynamic Atmospheric Drag/Compression Wave Glow around Rocket Tip */}
          {launched && !warpSpeed && (
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-16 h-8 flex flex-col items-center pointer-events-none z-20">
              <div className="w-16 h-4 border-t-[3px] border-cyan-400 rounded-full opacity-90 blur-[1px] animate-[pulse_0.1s_infinite_alternate]" />
              <div className="w-12 h-3 border-t-2 border-cyan-300 rounded-full opacity-60 blur-[2px] -mt-0.5 animate-ping" />
            </div>
          )}

          {/* Premium Vector 3D Rocket Body - Seamlessly Engineered */}
          <div className="relative w-28 h-64 select-none" id="vector-rocket-chassis">
            
            {/* 1. Sleek Ogive Nose Cone (inspired by sharp aerodynamics) */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-14 h-20 bg-gradient-to-b from-slate-100 via-slate-300 to-slate-450 dark:from-slate-200 dark:via-slate-450 dark:to-slate-650 rounded-t-[100%_180%] border-t border-x border-white/30 shadow-[inset_0_2px_4px_rgba(255,255,255,0.4)] z-10">
              {/* LED Beacon Light */}
              <span className="absolute top-3 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              <span className="absolute top-3 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_8px_rgb(239,68,68)]" />
            </div>

            {/* 2. Main Rocket Body Fuselage - Continues Tip slope continuously */}
            <div className="absolute top-[76px] left-1/2 -translate-x-1/2 w-14 h-32 bg-gradient-to-r from-slate-200 via-slate-100 to-slate-400 dark:from-slate-350 dark:via-slate-100 dark:to-slate-600 rounded-b-[30%_15px] border-x border-white/20 flex flex-col items-center justify-between py-5 shadow-2xl overflow-hidden z-10">
              <div className="absolute inset-y-0 left-0 w-[2px] bg-cyan-400/20 pointer-events-none" />
              <div className="absolute inset-y-0 right-0 w-[2px] bg-cyan-400/20 pointer-events-none" />
              
              {/* Outer Cabin circular viewport glass with active database radar scanning line */}
              <div className="w-9 h-9 rounded-full bg-slate-950 border-2 border-slate-400 dark:border-slate-500 flex items-center justify-center relative shadow-inner overflow-hidden z-10">
                {/* Viewport reflection glare */}
                <div className="absolute top-0 right-0 w-5 h-5 bg-white/10 rounded-full transform rotate-45 pointer-events-none" />
                {/* Scanline line */}
                <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-cyan-400/80 animate-[bounce_1.5s_infinite_alternate] shadow-[0_0_4px_#22d3ee]" />
                <span className="text-[7px] font-mono font-bold text-cyan-400 tracking-tighter z-10 drop-shadow-[0_0_2px_rgba(34,211,238,0.8)]">
                  {progress < 50 ? 'SYS' : progress < 90 ? 'THR' : 'WRP'}
                </span>
              </div>

              {/* Adam Abdul Mulani Signature branding inscription on body */}
              <div className="font-mono text-[6.5px] tracking-[0.18em] text-slate-400 dark:text-slate-500 font-bold uppercase rotate-90 my-2 whitespace-nowrap bg-black/45 border border-white/5 px-1.5 py-0.5 rounded select-none">
                CORE v4.2 // ADM
              </div>

              {/* Blue / Neon glowing core level line */}
              <div className="w-10 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse rounded-full shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
            </div>

            {/* 3. Left Wing Booster fin - Inspired by the sleek curves of the Tip */}
            <div 
              className="absolute bottom-[28px] left-[-4px] w-8 h-20 bg-gradient-to-l from-slate-400 to-slate-650 rounded-l-[100%_45%] origin-right border-l border-cyan-450/25 shadow-[0_0_8px_rgba(34,211,238,0.05)] z-10"
              style={{ transform: 'skewY(-12deg)' }}
            >
              <div className="w-full h-1 bg-cyan-400/70 shadow-[0_0_6px_rgba(6,182,212,0.6)] absolute bottom-3" />
            </div>

            {/* 4. Right Wing Booster fin - Inspired by the sleek curves of the Tip */}
            <div 
              className="absolute bottom-[28px] right-[-4px] w-8 h-20 bg-gradient-to-r from-slate-400 to-slate-650 rounded-r-[100%_45%] origin-left border-r border-cyan-450/25 shadow-[0_0_8px_rgba(34,211,238,0.05)] z-10"
              style={{ transform: 'skewY(12deg)' }}
            >
              <div className="w-full h-1 bg-cyan-400/70 shadow-[0_0_6px_rgba(6,182,212,0.6)] absolute bottom-3" />
            </div>

            {/* 5. Engine Combustion exhaust nozzle core in burnt titanium (Embedded gracefully in fuselage) */}
            <div className="absolute top-[200px] left-1/2 -translate-x-1/2 w-10 h-8 bg-gradient-to-b from-slate-800 to-slate-900 rounded-b-md shadow-inner border-t border-slate-700/80 z-10" />

            {/* 6. DYNAMIC JET THRUSTER PROPULSION ELEMENT (Fully attached inside nozzle bottom) */}
            {ignited && (
              <div className="absolute top-[204px] left-1/2 -translate-x-1/2 w-14 flex flex-col items-center pointer-events-none z-0">
                {/* Sparkly shockwave acoustic ring pulse */}
                <div className="absolute top-2 w-12 h-12 rounded-full border border-cyan-400/50 opacity-0 animate-[shockwave-ring_1.2s_infinite_linear]" />
                
                {/* Supersonic Mach Diamonds Overlays - matching the tip angles */}
                <div className="absolute top-[12px] w-4 h-4 bg-cyan-300 transform rotate-45 opacity-80 animate-[mach-pulse_0.15s_infinite_alternate]" />
                <div className="absolute top-[30px] w-3 h-3 bg-cyan-200 transform rotate-45 opacity-70 animate-[mach-pulse_0.15s_infinite_alternate] delay-75" />

                {/* Triple-Layer High-energy Fusion Fire Core - Nesting and Attached */}
                {/* Outer Fire Plume (Flaring Orange-Red) */}
                <motion.div
                  animate={{
                    height: [110, 160, 110],
                    width: [34, 48, 34],
                  }}
                  transition={{
                    duration: 0.12,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                  className="absolute top-2 bg-gradient-to-b from-orange-400 via-orange-650 to-transparent rounded-t-full origin-top"
                  style={{
                    boxShadow: '0 0 25px #ea580c, 0 0 50px #dc2626'
                  }}
                />

                {/* Outer Yellow Halo */}
                <motion.div
                  animate={{
                    height: [95, 130, 95],
                    width: [26, 38, 26],
                  }}
                  transition={{
                    duration: 0.08,
                    repeat: Infinity,
                    ease: "linear",
                    delay: 0.03
                  }}
                  className="absolute top-2 bg-gradient-to-b from-yellow-300 via-yellow-500 to-transparent rounded-t-full origin-top"
                  style={{
                    boxShadow: '0 0 18px #facc15'
                  }}
                />

                {/* Inner plasma fusion core (Teal/Cyan-White Center) */}
                <motion.div
                  animate={{
                    height: [60, 90, 60],
                    width: [16, 24, 16],
                  }}
                  transition={{
                    duration: 0.05,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                  className="absolute top-2 bg-gradient-to-b from-white via-cyan-400 to-transparent rounded-t-full origin-top z-10"
                  style={{
                    boxShadow: '0 0 15px #06b6d4, 0 0 35px #22d3ee'
                  }}
                />

                {/* CSS Spark Waterfall (Random delay paths) */}
                <div className="absolute bottom-[-100px] w-24 h-48 overflow-visible flex justify-center pointer-events-none">
                  <span className="absolute w-1.5 h-1.5 rounded-full bg-cyan-300 animate-[spark-float-1_0.9s_infinite_linear]" style={{ animationDelay: '0.1s' }} />
                  <span className="absolute w-1.0 h-1.0 rounded-full bg-orange-400 animate-[spark-float-2_1.1s_infinite_linear]" style={{ animationDelay: '0.3s' }} />
                  <span className="absolute w-2.0 h-2.0 rounded-full bg-white animate-[spark-float-3_0.7s_infinite_linear]" style={{ animationDelay: '0s' }} />
                  <span className="absolute w-1.2 h-1.2 rounded-full bg-yellow-400 animate-[spark-float-4_1.3s_infinite_linear]" style={{ animationDelay: '0.5s' }} />
                  <span className="absolute w-1.5 h-1.5 rounded-full bg-cyan-200 animate-[spark-float-2_0.8s_infinite_linear]" style={{ animationDelay: '0.2s' }} />
                  <span className="absolute w-1.0 h-1.0 rounded-full bg-orange-500 animate-[spark-float-1_1.2s_infinite_linear]" style={{ animationDelay: '0.6s' }} />
                  <span className="absolute w-2.0 h-2.0 rounded-full bg-cyan-400 animate-[spark-float-4_0.9s_infinite_linear]" style={{ animationDelay: '0.4s' }} />
                  <span className="absolute w-1.2 h-1.2 rounded-full bg-white animate-[spark-float-3_1.0s_infinite_linear]" style={{ animationDelay: '0.7s' }} />
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Cinematic Flare effect layout */}
        {warpSpeed && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: [1, 0.5], scale: [8, 12] }}
            transition={{ duration: 1 }}
            className="absolute z-30 bg-cyan-400/35 rounded-full filter blur-xl w-32 h-32 pointer-events-none"
          />
        )}
      </div>

      {/* DISPLAY MESSAGING & DIGITAL DIALS */}
      <div className="w-full max-w-xl text-center z-10 flex flex-col items-center">
        
        {/* Primary Load Status Banner */}
        <AnimatePresence mode="wait">
          <motion.div
            key={statusMessage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="flex items-center gap-2 mb-3.5"
            id="status-feed-container"
          >
            {ignited ? (
              <Flame size={16} className="text-orange-500 animate-bounce" />
            ) : (
              <span className="w-2 h-2 rounded-full bg-blue-500 dark:bg-cyan-400 animate-ping" />
            )}
            <span className="font-poppins font-bold text-xs sm:text-sm text-white uppercase tracking-widest bg-slate-900 border border-slate-800 px-3 py-1 rounded-md">
              {statusMessage}
            </span>
          </motion.div>
        </AnimatePresence>

        {/* Digital Counter Display 001% - 100% */}
        <div className="flex flex-col items-center relative" id="hud-loading-counter">
          <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase font-extrabold block mb-1">
            Engine Power Grid
          </span>
          <div className="font-display font-bold text-5xl sm:text-7xl leading-none text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-200 to-slate-400 tracking-tighter drop-shadow-[0_0_15px_rgba(255,255,255,0.15)] flex items-center justify-center">
            {formatPercentage(progress)}
            <span className="text-xs font-mono text-cyan-400 ml-1.5 self-end mb-1 sm:mb-2">%</span>
          </div>
        </div>

        {/* Cinematic System diagnostics lines progress bar */}
        <div className="w-full h-[3px] bg-slate-900 border border-slate-800 rounded-full mt-6 relative overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-600 via-cyan-400 to-white transition-all duration-700"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Grid specifications status metrics */}
        <div className="w-full flex justify-between items-center mt-3 font-mono text-[9px] text-slate-500 px-1">
          <span>PORT 3000 // DEPLOYMENT</span>
          <span>COSMIC COMPILER: 27B</span>
        </div>
      </div>

      {/* Camera Shake Injector Class Helper Styles */}
      <style>{`
        @keyframes camera-shake {
          0% { transform: translate(1px, 1px) rotate(0deg); }
          10% { transform: translate(-1px, -2px) rotate(-1deg); }
          20% { transform: translate(-3px, 0px) rotate(1deg); }
          30% { transform: translate(0px, 2px) rotate(0deg); }
          40% { transform: translate(1px, -1px) rotate(1deg); }
          50% { transform: translate(-1px, 2px) rotate(-1deg); }
          60% { transform: translate(-3px, 1px) rotate(0deg); }
          70% { transform: translate(2px, 1px) rotate(-1deg); }
          80% { transform: translate(-1px, -1px) rotate(1deg); }
          90% { transform: translate(2px, 2px) rotate(0deg); }
          100% { transform: translate(1px, -2px) rotate(-1deg); }
        }
        @keyframes spark-float-1 {
          0% { transform: translate(0, 0) scale(1); opacity: 1; }
          100% { transform: translate(-28px, 130px) scale(0.2); opacity: 0; }
        }
        @keyframes spark-float-2 {
          0% { transform: translate(0, 0) scale(1); opacity: 1; }
          100% { transform: translate(28px, 150px) scale(0.15); opacity: 0; }
        }
        @keyframes spark-float-3 {
          0% { transform: translate(0, 0) scale(1.3); opacity: 1; }
          100% { transform: translate(-10px, 175px) scale(0.3); opacity: 0; }
        }
        @keyframes spark-float-4 {
          0% { transform: translate(0, 0) scale(0.9); opacity: 1; }
          100% { transform: translate(18px, 135px) scale(0.1); opacity: 0; }
        }
        @keyframes mach-pulse {
          0% { transform: scaleX(0.8) rotate(45deg); opacity: 0.7; }
          100% { transform: scaleX(1.15) rotate(45deg); opacity: 1; }
        }
        @keyframes shockwave-ring {
          0% { transform: scale(0.3); opacity: 0.95; border-color: rgba(6, 182, 212, 0.85); }
          100% { transform: scale(2.4); opacity: 0; border-color: rgba(249, 115, 22, 0); }
        }
      `}</style>
    </div>
  );
}
