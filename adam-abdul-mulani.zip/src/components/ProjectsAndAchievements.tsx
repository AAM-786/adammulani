import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Code2, ShieldAlert, Cpu, Award, Zap, Heart, Eye, Github, Network } from 'lucide-react';
import { projectsList, achievementsList, extracurriculars } from '../data';

export default function ProjectsAndAchievements() {
  const [filter, setFilter] = useState<'all' | 'ai' | 'security' | 'web'>('all');

  const filteredProjects = projectsList.filter((proj) => {
    if (filter === 'all') return true;
    return proj.category === filter;
  });

  const filterTabs = [
    { label: 'All Projects', value: 'all' as const },
    { label: 'AI & Data Science', value: 'ai' as const },
    { label: 'Cyber Security', value: 'security' as const },
    { label: 'Web & Systems', value: 'web' as const },
  ];

  const getProjectIcon = (category: string) => {
    switch (category) {
      case 'ai':
        return <Cpu size={20} className="text-blue-600 dark:text-cyan-400 animate-pulse" />;
      case 'security':
        return <ShieldAlert size={20} className="text-red-500 dark:text-rose-400" />;
      default:
        return <Code2 size={20} className="text-slate-700 dark:text-emerald-400" />;
    }
  };

  return (
    <section id="projects" className="py-24 bg-slate-50 dark:bg-slate-950 transition-colors border-t border-slate-100 dark:border-slate-900 scroll-mt-20">
      <div className="responsive-container">
        
        {/* SECTION HEADER */}
        <div className="text-center max-w-3xl mx-auto mb-16 no-print">
          <h2 className="font-display font-medium text-xs tracking-widest text-blue-600 dark:text-cyan-400 uppercase">
            Showcase
          </h2>
          <p className="mt-2 font-display font-bold text-3xl sm:text-4xl text-slate-900 dark:text-white tracking-tight">
            Innovative Technical Endeavors
          </p>
          <div className="mt-4 w-12 h-1 bg-gradient-to-r from-blue-600 to-cyan-500 mx-auto rounded-full" />
        </div>

        {/* PROJECT FILTER CONTROLS */}
        <div className="flex flex-wrap justify-center gap-2 mb-12 no-print" id="project-filter-buttons">
          {filterTabs.map((tab) => (
            <button
              key={tab.value}
              onClick={() => setFilter(tab.value)}
              className={`px-5 py-2.5 rounded-full text-xs font-semibold tracking-wide uppercase transition-all cursor-pointer border ${
                filter === tab.value
                  ? 'bg-slate-900 text-white border-slate-900 dark:bg-cyan-500 dark:text-slate-950 dark:border-cyan-500 shadow-md shadow-blue-500/10'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-350 dark:bg-slate-900 dark:text-slate-350 dark:border-slate-800 dark:hover:border-slate-700'
              }`}
              id={`filter-btn-${tab.value}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* PROJECTS GRID DISPLAY */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24"
          id="projects-gallery-grid"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((proj) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.92 }}
                transition={{ duration: 0.3 }}
                key={proj.id}
                className="glass-panel border rounded-3xl p-6 sm:p-7 flex flex-col justify-between shadow-sm hover:shadow-lg hover:border-slate-300 dark:hover:border-slate-800 transition-all group"
                id={`project-card-${proj.id}`}
              >
                <div>
                  <div className="flex justify-between items-start mb-5">
                    <div className="p-3 bg-slate-100 dark:bg-slate-900 rounded-2xl group-hover:scale-110 transition-transform">
                      {getProjectIcon(proj.category)}
                    </div>
                    {/* Floating mini status indicator */}
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-md bg-blue-50 dark:bg-cyan-950/40 text-blue-700 dark:text-cyan-400 border border-blue-100/30 dark:border-cyan-900/10">
                      {proj.category === 'ai' ? 'AI / ML' : proj.category === 'security' ? 'Security' : 'Web & App'}
                    </span>
                  </div>

                  <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-2.5 group-hover:text-blue-600 dark:group-hover:text-cyan-400 transition-colors">
                    {proj.title}
                  </h3>

                  <p className="font-sans text-sm text-slate-500 dark:text-slate-400 leading-relaxed min-h-[72px]">
                    {proj.description}
                  </p>
                </div>

                <div className="mt-6">
                  {/* Technology labels */}
                  <div className="flex flex-wrap gap-1.5 mb-5">
                    {proj.technologies.slice(0, 4).map((tech) => (
                      <span
                        key={tech}
                        className="px-2.5 py-0.5 text-[10px] font-mono rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Operational indicators / buttons */}
                  <div className="pt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                    <a
                      href={proj.githubUrl || "https://github.com/adamamulani786"}
                      target="_blank"
                      rel="noreferrer"
                      referrerPolicy="no-referrer"
                      className="text-xs font-mono font-medium text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-cyan-400 transition-colors inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Github size={13} />
                      <span>Codebase</span>
                    </a>
                    <a
                      href={proj.demoUrl || "https://github.com/adamamulani786"}
                      target="_blank"
                      rel="noreferrer"
                      referrerPolicy="no-referrer"
                      className="text-xs font-mono font-bold text-blue-600 hover:text-blue-700 dark:text-cyan-400 dark:hover:text-cyan-300 transition-colors inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Eye size={13} />
                      <span>Launch Run</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* ACHIEVEMENTS & EXTRACURRICULAR DOUBLE SECTIONS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mt-24">
          
          {/* Achievements Highlight */}
          <div className="lg:col-span-7 space-y-6" id="achievements-highlights-panel">
            <h3 className="font-display font-bold text-2xl text-slate-900 dark:text-white flex items-center gap-2.5">
              <span className="p-2 bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-cyan-400 rounded-xl">
                <Award size={20} />
              </span>
              <span>Key Career Milestones</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {achievementsList.map((ach) => (
                <div
                  key={ach.id}
                  className="p-5 rounded-2xl border border-slate-100 dark:border-slate-800/85 bg-white dark:bg-slate-900/40 shadow-xs flex items-start gap-3.5 hover:border-slate-200 dark:hover:border-slate-800 transition-colors"
                  id={`ach-item-${ach.id}`}
                >
                  <div className="p-1.5 bg-blue-50 dark:bg-cyan-950/40 text-blue-600 dark:text-cyan-400 rounded-lg shrink-0 mt-0.5">
                    <Zap size={14} />
                  </div>
                  <div className="space-y-0.5">
                    <p className="font-sans font-extrabold text-sm text-slate-800 dark:text-slate-100">
                      {ach.title}
                    </p>
                    <p className="font-sans text-xs text-slate-405 dark:text-slate-400">
                      {ach.detail}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Extracurricular details */}
          <div className="lg:col-span-5 space-y-6" id="extracurriculars-highlights-panel">
            <h3 className="font-display font-bold text-2xl text-slate-900 dark:text-white flex items-center gap-2.5">
              <span className="p-2 bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-cyan-400 rounded-xl">
                <Heart size={20} />
              </span>
              <span>Extracurricular Civic Duty</span>
            </h3>

            {extracurriculars.map((extra) => (
              <div
                key={extra.id}
                className="p-6 rounded-3xl border border-blue-100/50 dark:border-cyan-900/20 bg-blue-50/20 dark:bg-cyan-950/10 shadow-xs relative overflow-hidden"
                id={`extra-card-${extra.id}`}
              >
                {/* Floating decor sphere */}
                <div className="absolute -bottom-10 -left-10 w-24 h-24 bg-blue-500/10 rounded-full blur-xl" />
                
                <h4 className="font-display font-bold text-base text-slate-900 dark:text-white mb-3">
                  {extra.title}
                </h4>

                <p className="font-sans text-sm text-slate-600 dark:text-slate-350 leading-relaxed font-light">
                  {extra.description}
                </p>

                <div className="mt-5 text-[10px] font-mono tracking-wider font-semibold uppercase text-blue-600 dark:text-cyan-400">
                  Navi Mumbai Outreach Team
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
}
