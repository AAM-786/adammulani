import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AboutAndInfo from './components/AboutAndInfo';
import TimelineAndExperience from './components/TimelineAndExperience';
import SkillsAndCertifications from './components/SkillsAndCertifications';
import ProjectsAndAchievements from './components/ProjectsAndAchievements';
import ContactAndFooter from './components/ContactAndFooter';
import LaunchPreloader from './components/LaunchPreloader';
import ScrollSystem from './components/ScrollSystem';
import PrintResumeSheet from './components/PrintResumeSheet';
import AskBot from './components/AskBot';
import ResumeModal from './components/ResumeModal';

export default function App() {
  const [showPreloader, setShowPreloader] = useState(true);
  const [revealStage, setRevealStage] = useState<'pre' | 'flash' | 'portal-logo' | 'full-display'>('pre');
  
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('theme') as 'light' | 'dark') || 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  // Launch preloader completed, trigger sequential cinematic pipeline
  const handleLaunchCompleted = () => {
    setRevealStage('flash');
    
    // Step 1: Show full white flash, then transfer into Portal Logo state
    setTimeout(() => {
      setRevealStage('portal-logo');
    }, 400);

    // Step 2: Show glowing portfolio icon, then fade into the actual Web App grid
    setTimeout(() => {
      setRevealStage('full-display');
      setShowPreloader(false);
    }, 1500);
  };

  // Automated Scroll Recovery System for Anchor Hash Redirects
  useEffect(() => {
    if (revealStage === 'full-display') {
      const currentHash = window.location.hash;
      if (currentHash) {
        // Wait briefly for elements to be fully painted and layout compiled
        const timer = setTimeout(() => {
          const targetId = currentHash.replace('#', '');
          const element = document.getElementById(targetId);
          if (element) {
            const rect = element.getBoundingClientRect();
            const absoluteTop = rect.top + (window.pageYOffset || document.documentElement.scrollTop);
            const offsetTop = absoluteTop - 80;
            window.scrollTo({
              top: offsetTop,
              behavior: 'smooth',
            });
          }
        }, 500);
        return () => clearTimeout(timer);
      }
    }
  }, [revealStage]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 transition-colors duration-300 relative overflow-x-hidden">
      
      {/* 0. PRINTABLE RESUME SHEET (Active strictly under physical media prints) */}
      <PrintResumeSheet />
      <ResumeModal />
      
      {/* 1. CINEMATIC ROCKET PRELOADER */}
      <AnimatePresence>
        {showPreloader && revealStage === 'pre' && (
          <motion.div
            key="preloader-overlay"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="fixed inset-0 z-50 pointer-events-auto"
          >
            <LaunchPreloader onComplete={handleLaunchCompleted} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. WHITE FLASH REVEAL TRANSITION EFFECT */}
      <AnimatePresence>
        {revealStage === 'flash' && (
          <motion.div
            key="flash-effect"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 bg-white z-[1000] pointer-events-none"
          />
        )}
      </AnimatePresence>

      {/* 3. CENTERED PORTFOLIO LOGO STAGE PORTAL */}
      <AnimatePresence>
        {revealStage === 'portal-logo' && (
          <motion.div
            key="portal-stage"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.3, filter: 'blur(10px)' }}
            transition={{ duration: 0.45 }}
            className="fixed inset-0 flex flex-col items-center justify-center bg-slate-950 z-[900] pointer-events-none"
          >
            {/* Spinning Holographic Portal Decal */}
            <div className="p-6 bg-blue-600/10 dark:bg-cyan-500/10 rounded-full border border-cyan-400/30 animate-spin" style={{ animationDuration: '8s' }}>
              <div className="p-4 bg-cyan-500 rounded-3xl text-slate-950 shadow-[0_0_50px_rgba(6,182,212,0.6)]">
                <Terminal size={48} className="animate-pulse" />
              </div>
            </div>
            
            <motion.h2 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-6 font-display font-bold text-2xl text-white tracking-widest uppercase text-center"
            >
              Adam Abdul Mulani
            </motion.h2>
            <p className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase mt-1">
              Establishing AI & Data Science Tomorrow
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 4. MAIN PRODUCTIVE PORTFOLIO APPLICATION */}
      {revealStage === 'full-display' && (
        <div id="full-portfolio-app" className="no-print">
          <ScrollSystem />
          <AskBot />
          
          {/* Main Sections flow: Fade-in & staggered slides */}
          <main className="relative z-0">
            {/* Hero slide up reveal */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.95, ease: 'easeOut' }}
            >
              <Hero theme={theme} />
            </motion.div>

            {/* Other sections fade-in sequentially on window interaction */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              <AboutAndInfo />
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.7 }}
            >
              <TimelineAndExperience />
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.9 }}
            >
              <SkillsAndCertifications />
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 1.1 }}
            >
              <ProjectsAndAchievements />
            </motion.div>

            <ContactAndFooter />
          </main>

          {/* Animated Navigation Container - placed at end for foolproof click interaction */}
          <Navbar theme={theme} toggleTheme={toggleTheme} />
        </div>
      )}
    </div>
  );
}


