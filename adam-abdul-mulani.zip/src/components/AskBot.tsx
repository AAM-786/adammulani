import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, X, Send, Trash2, ArrowRight, MessageSquareCode, User, Minimize2 } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const SUGGESTIONS = [
  "What is Adam's B.E. specialization?",
  "Tell me about his CodeAlpha AI Internship",
  "Summarize his technical projects",
  "Is Adam based in Navi Mumbai?"
];

export default function AskBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      text: "👋 Hello there! I am **AskBot**, Adam Abdul Mulani's professional AI companion. Ask me anything about his qualifications, scholastic metrics, computer code sandboxes, or industry internships!",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to lowest message on chat update
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}-user`,
      text: textToSend,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    try {
      // Map history for basic context awareness on server-side
      const chatHistory = messages.map(m => ({
        role: m.sender === 'user' ? 'user' : 'model',
        text: m.text
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: textToSend, history: chatHistory })
      });

      if (!res.ok) {
        throw new Error("Chat fetch failed.");
      }

      const data = await res.json();
      const botMsg: Message = {
        id: `msg-${Date.now()}-bot`,
        text: data.reply,
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      const botErrorMsg: Message = {
        id: `msg-${Date.now()}-bot-err`,
        text: "🚨 I had trouble reaching Adam's server logic. I can still happily inform you that Adam Abdul Mulani is a brilliant AI & Data Science B.E. student at A.C. Patil College of Engineering, with high-scoring MSBTE diploma credentials (89.06%)!",
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botErrorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: 'welcome-reset',
        text: "🔄 Chat system flushed. Ready for active telemetry. Ask me anything about Adam Abdul Mulani!",
        sender: 'bot',
        timestamp: new Date()
      }
    ]);
  };

  return (
    <div className="fixed bottom-6 right-[88px] z-[9999] no-print" id="ask-bot-container">
      {/* 1. COMPACT CHAT TOGGLE BUBBLE */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={`w-14 h-14 rounded-full flex items-center justify-center cursor-pointer shadow-lg transition-all duration-300 relative border border-slate-350 dark:border-slate-800 ${
          isOpen 
            ? 'bg-rose-600 text-white' 
            : 'glass-panel text-slate-800 dark:text-white bg-white/70 dark:bg-slate-950/70 hover:border-cyan-400 dark:hover:border-cyan-500'
        }`}
        title="Dialogue with AskBot AI Code Companion"
        id="ask-bot-toggle-btn"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <Minimize2 size={22} />
            </motion.div>
          ) : (
            <motion.div
              key="bot"
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative flex items-center justify-center"
            >
              <Bot size={22} className="text-blue-600 dark:text-cyan-400" />
              <span className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-cyan-500 rounded-full animate-ping" />
              <span className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-cyan-500 rounded-full" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* 2. SLIDING AI DIALOG TERMINAL WINDOW */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 35, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ type: 'spring', damping: 23, stiffness: 280 }}
            className="absolute bottom-16 right-0 w-[360px] max-w-[calc(100vw-2.5rem)] h-[525px] rounded-3xl border border-slate-200/50 dark:border-slate-800 bg-white/95 dark:bg-slate-950/95 backdrop-blur-xl shadow-2xl overflow-hidden flex flex-col pointer-events-auto"
            id="ask-bot-dialog-window"
          >
            {/* Header console title bar */}
            <div className="px-5 py-4 border-b border-slate-200/50 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-600/10 dark:bg-cyan-500/10 flex items-center justify-center text-blue-600 dark:text-cyan-400">
                  <Bot size={18} className="animate-pulse" />
                </div>
                <div>
                  <h3 className="font-display font-black text-xs tracking-wider text-slate-800 dark:text-white uppercase flex items-center gap-1.5">
                    AskBot AI
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  </h3>
                  <p className="text-[9px] font-mono font-medium text-slate-400 uppercase tracking-widest">
                    Automated Intelligence
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={clearChat}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 dark:hover:bg-rose-500/10 transition-all cursor-pointer"
                  title="Purge dialogue logs"
                >
                  <Trash2 size={13} />
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-200/50 dark:hover:bg-slate-900/50 transition-all cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>
            </div>

            {/* Content chat scroll body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 scrollbar-thin dark:scrollbar-thumb-slate-800 dark:scrollbar-track-transparent">
              {messages.map((m) => {
                const isBot = m.sender === 'bot';
                return (
                  <div
                    key={m.id}
                    className={`flex gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
                  >
                    {isBot && (
                      <div className="w-7 h-7 rounded-lg bg-blue-600/10 dark:bg-cyan-500/10 text-blue-600 dark:text-cyan-400 flex items-center justify-center shrink-0 self-start">
                        <Bot size={14} />
                      </div>
                    )}
                    
                    <div className="max-w-[80%] space-y-1">
                      <div
                        className={`px-3.5 py-2.5 text-xs leading-relaxed font-sans rounded-2xl ${
                          isBot
                            ? 'bg-slate-100 dark:bg-slate-900/60 text-slate-800 dark:text-slate-200 rounded-tl-sm border border-slate-200/30 dark:border-slate-850'
                            : 'bg-blue-600 dark:bg-cyan-500 text-white rounded-tr-sm'
                        }`}
                      >
                        {/* Custom rudimentary markdown replacement for bold markings */}
                        {m.text.split('\n\n').map((para, pIdx) => (
                          <p key={pIdx} className={pIdx > 0 ? 'mt-2' : ''}>
                            {para.split('**').map((str, sIdx) => {
                              if (sIdx % 2 === 1) {
                                return <strong key={sIdx} className="font-extrabold text-blue-700 dark:text-cyan-300">{str}</strong>;
                              }
                              return str;
                            })}
                          </p>
                        ))}
                      </div>
                      <span className="block text-[8px] font-mono text-slate-400 dark:text-slate-500 uppercase tracking-wider text-right px-1">
                        {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    {!isBot && (
                      <div className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center shrink-0 self-start">
                        <User size={13} />
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Typing Blinker Indicator */}
              {isTyping && (
                <div className="flex gap-2.5 justify-start">
                  <div className="w-7 h-7 rounded-lg bg-blue-600/10 dark:bg-cyan-500/10 text-blue-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
                    <Bot size={14} />
                  </div>
                  <div className="px-3.5 py-2.5 bg-slate-100 dark:bg-slate-900/60 text-slate-400 rounded-2xl rounded-tl-sm border border-slate-200/30 dark:border-slate-850 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Quick suggested chips block */}
            {messages.length < 5 && (
              <div className="px-5 py-2 overflow-x-auto whitespace-nowrap flex gap-1.5 border-t border-slate-200/30 dark:border-slate-900 scrollbar-none select-none">
                {SUGGESTIONS.map((sug) => (
                  <button
                    key={sug}
                    onClick={() => handleSendMessage(sug)}
                    className="flex items-center gap-1 px-3 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-900/80 dark:hover:bg-slate-800 rounded-full text-[10px] font-sans font-medium text-slate-600 dark:text-slate-400 border border-slate-200/50 dark:border-slate-850 cursor-pointer shrink-0 transition-colors"
                  >
                    <span>{sug}</span>
                    <ArrowRight size={10} className="text-slate-400" />
                  </button>
                ))}
              </div>
            )}

            {/* Input prompt dispatcher section */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputValue);
              }}
              className="p-4 border-t border-slate-200/50 dark:border-slate-800 bg-slate-50/30 dark:bg-slate-900/20 flex gap-2"
            >
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about education, internships, scores..."
                className="flex-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 focus:border-cyan-400 dark:focus:border-cyan-500 font-sans text-xs text-slate-800 dark:text-slate-250 px-3.5 py-2.5 rounded-xl outline-none transition-all"
                id="ask-bot-prompt-input"
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isTyping}
                className="p-2.5 rounded-xl bg-blue-600 dark:bg-cyan-500 hover:bg-blue-700 dark:hover:bg-cyan-600 text-white transition-all duration-200 shrink-0 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center shadow-md active:scale-95 border-none"
              >
                <Send size={14} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
