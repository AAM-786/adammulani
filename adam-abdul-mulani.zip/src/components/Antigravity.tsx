/* eslint-disable react/no-unknown-property */
import React, { useMemo, useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree, RootState } from '@react-three/fiber';
import * as THREE from 'three';

interface Particle {
  t: number;
  factor: number;
  speed: number;
  xFactor: number;
  yFactor: number;
  zFactor: number;
  mx: number;
  my: number;
  mz: number;
  cx: number;
  cy: number;
  cz: number;
  vx: number;
  vy: number;
  vz: number;
  randomRadiusOffset: number;
}

interface AntigravityInnerProps {
  count: number;
  magnetRadius: number;
  ringRadius: number;
  waveSpeed: number;
  waveAmplitude: number;
  particleSize: number;
  lerpSpeed: number;
  color: string;
  autoAnimate: boolean;
  particleVariance: number;
  rotationSpeed: number;
  depthFactor: number;
  pulseSpeed: number;
  particleShape: 'capsule' | 'sphere' | 'box' | 'tetrahedron';
  fieldStrength: number;
}

const AntigravityInner: React.FC<AntigravityInnerProps> = ({
  count,
  magnetRadius,
  ringRadius,
  waveSpeed,
  waveAmplitude,
  particleSize,
  lerpSpeed,
  color,
  autoAnimate,
  particleVariance,
  rotationSpeed,
  depthFactor,
  pulseSpeed,
  particleShape,
  fieldStrength
}) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const { viewport } = useThree();
  const dummy = useMemo(() => new THREE.Object3D(), []);

  // Set default coordinates far off screen to prevent initial center ring layout artifact
  const windowMouse = useRef({ x: -9999, y: -9999 });
  const lastMousePos = useRef({ x: 0, y: 0 });
  const mouseDirection = useRef({ x: 0, y: 0 });
  const mouseSpeed = useRef(0);
  const lastMouseMoveTime = useRef(0);
  const virtualMouse = useRef({ x: 0, y: 0 });
  const accumulatedRotation = useRef(0);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const currentX = (e.clientX / window.innerWidth) * 2 - 1;
      const currentY = -(e.clientY / window.innerHeight) * 2 + 1;

      // Initialize last position on initial movement detection
      if (windowMouse.current.x === -9999) {
        lastMousePos.current = { x: currentX, y: currentY };
      }

      const dx = currentX - lastMousePos.current.x;
      const dy = currentY - lastMousePos.current.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      if (distance > 0.001) {
        mouseDirection.current.x = dx / distance;
        mouseDirection.current.y = dy / distance;
        mouseSpeed.current = Math.min(distance * 35, 4.0);
      } else {
        mouseSpeed.current *= 0.85;
      }

      windowMouse.current.x = currentX;
      windowMouse.current.y = currentY;
      lastMousePos.current = { x: currentX, y: currentY };
      lastMouseMoveTime.current = Date.now();
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const particles = useMemo(() => {
    const temp: Particle[] = [];
    const width = viewport.width || 100;
    const height = viewport.height || 100;

    for (let i = 0; i < count; i++) {
      const t = Math.random() * 100;
      const factor = 20 + Math.random() * 100;
      const speed = 0.01 + Math.random() / 200;
      const xFactor = -50 + Math.random() * 100;
      const yFactor = -50 + Math.random() * 100;
      const zFactor = -50 + Math.random() * 100;

      const x = (Math.random() - 0.5) * width;
      const y = (Math.random() - 0.5) * height;
      const z = (Math.random() - 0.5) * 20;

      const randomRadiusOffset = (Math.random() - 0.5) * 2;

      temp.push({
        t,
        factor,
        speed,
        xFactor,
        yFactor,
        zFactor,
        mx: x,
        my: y,
        mz: z,
        cx: x,
        cy: y,
        cz: z,
        vx: 0,
        vy: 0,
        vz: 0,
        randomRadiusOffset
      });
    }
    return temp;
  }, [count, viewport.width, viewport.height]);

  useFrame((state: RootState) => {
    // 1. Tab Minimization & Tab Switch Performance Optimization
    if (document.hidden) return;

    const mesh = meshRef.current;
    if (!mesh) return;

    const { viewport: v } = state;
    const m = windowMouse.current;

    if (Date.now() - lastMouseMoveTime.current > 100) {
      mouseSpeed.current *= 0.94;
    }

    const hasMouseMoved = m.x !== -9999;
    let destX = hasMouseMoved ? (m.x * v.width) / 2 : 0;
    let destY = hasMouseMoved ? (m.y * v.height) / 2 : 0;

    if (autoAnimate && Date.now() - lastMouseMoveTime.current > 2000) {
      const time = state.clock.getElapsedTime();
      destX = Math.sin(time * 0.5) * (v.width / 4);
      destY = Math.cos(time * 0.5 * 2) * (v.height / 4);
    }

    const smoothFactor = 0.05;
    virtualMouse.current.x += (destX - virtualMouse.current.x) * smoothFactor;
    virtualMouse.current.y += (destY - virtualMouse.current.y) * smoothFactor;

    const targetX = virtualMouse.current.x;
    const targetY = virtualMouse.current.y;

    const currentMouseDir = mouseDirection.current;
    const currentMouseSpeed = mouseSpeed.current;

    // Rotate particles only based on real mouse motion
    accumulatedRotation.current += rotationSpeed * 0.015 * currentMouseSpeed;
    const globalRotation = accumulatedRotation.current;

    particles.forEach((particle, i) => {
      let { mz, cz, randomRadiusOffset } = particle;

      // Advance particles time purely based on mouse speed to eliminate raw idle movement
      if (currentMouseSpeed > 0.01) {
        particle.t += (particle.speed / 2) * currentMouseSpeed * 1.5;
      }
      const t = particle.t;

      const projectionFactor = 1 - cz / 50;
      const projectedTargetX = targetX * projectionFactor;
      const projectedTargetY = targetY * projectionFactor;

      const dx = particle.mx - projectedTargetX;
      const dy = particle.my - projectedTargetY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      const targetPos = { x: particle.mx, y: particle.my, z: mz * depthFactor };

      const isMagnified = hasMouseMoved && (dist < magnetRadius);

      if (isMagnified) {
        const angle = Math.atan2(dy, dx) + globalRotation;

        const wave = Math.sin(t * waveSpeed + angle) * (0.5 * waveAmplitude);
        const deviation = randomRadiusOffset * (5 / (fieldStrength + 0.1));

        const currentRingRadius = ringRadius + wave + deviation;

        targetPos.x = projectedTargetX + currentRingRadius * Math.cos(angle);
        targetPos.y = projectedTargetY + currentRingRadius * Math.sin(angle);
        targetPos.z = mz * depthFactor + Math.sin(t) * (1 * waveAmplitude * depthFactor) + (currentMouseSpeed * (1 - dist / magnetRadius) * 8);
      }

      particle.cx += (targetPos.x - particle.cx) * lerpSpeed;
      particle.cy += (targetPos.y - particle.cy) * lerpSpeed;
      particle.cz += (targetPos.z - particle.cz) * lerpSpeed;

      dummy.position.set(particle.cx, particle.cy, particle.cz);

      dummy.lookAt(projectedTargetX, projectedTargetY, particle.cz);
      dummy.rotateX(Math.PI / 2);

      if (isMagnified && currentMouseSpeed > 0.05) {
        dummy.rotateY(currentMouseSpeed * (1 - dist / magnetRadius) * 0.7);
      }

      let scaleFactor = 0.0;
      if (hasMouseMoved) {
        const currentDistToMouse = Math.sqrt(
          Math.pow(particle.cx - projectedTargetX, 2) + Math.pow(particle.cy - projectedTargetY, 2)
        );
        const distFromRing = Math.abs(currentDistToMouse - ringRadius);
        scaleFactor = 1 - distFromRing / 12;
        scaleFactor = Math.max(0, Math.min(1, scaleFactor));
      } else {
        // Subtle decorative grid outline on startup prior to any mouse triggers
        scaleFactor = 0.04;
      }

      const scaleBoost = 1 + currentMouseSpeed * 0.5 * (isMagnified ? (1 - dist / magnetRadius) : 0);
      const finalScale = scaleFactor * (0.8 + Math.sin(t * pulseSpeed) * 0.2 * particleVariance) * particleSize * scaleBoost;
      dummy.scale.set(finalScale, finalScale, finalScale);

      dummy.updateMatrix();

      mesh.setMatrixAt(i, dummy.matrix);
    });

    mesh.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[null as any, null as any, count]} frustumCulled={true}>
      {particleShape === 'capsule' && <capsuleGeometry args={[0.1, 0.4, 4, 8]} />}
      {particleShape === 'sphere' && <sphereGeometry args={[0.2, 16, 16]} />}
      {particleShape === 'box' && <boxGeometry args={[0.3, 0.3, 0.3]} />}
      {particleShape === 'tetrahedron' && <tetrahedronGeometry args={[0.3]} />}
      <meshBasicMaterial color={color} />
    </instancedMesh>
  );
};

export interface AntigravityProps {
  count?: number;
  magnetRadius?: number;
  ringRadius?: number;
  waveSpeed?: number;
  waveAmplitude?: number;
  particleSize?: number;
  lerpSpeed?: number;
  color?: string;
  autoAnimate?: boolean;
  particleVariance?: number;
  rotationSpeed?: number;
  depthFactor?: number;
  pulseSpeed?: number;
  particleShape?: 'capsule' | 'sphere' | 'box' | 'tetrahedron';
  fieldStrength?: number;
}

const Antigravity: React.FC<AntigravityProps> = ({
  count = 300,
  magnetRadius = 10,
  ringRadius = 10,
  waveSpeed = 0.4,
  waveAmplitude = 1,
  particleSize = 2,
  lerpSpeed = 0.1,
  color = '#FF9FFC',
  autoAnimate = false,
  particleVariance = 1,
  rotationSpeed = 0,
  depthFactor = 1,
  pulseSpeed = 3,
  particleShape = 'capsule',
  fieldStrength = 10
}) => {
  return (
    <Canvas camera={{ position: [0, 0, 50], fov: 35 }}>
      <AntigravityInner
        count={count}
        magnetRadius={magnetRadius}
        ringRadius={ringRadius}
        waveSpeed={waveSpeed}
        waveAmplitude={waveAmplitude}
        particleSize={particleSize}
        lerpSpeed={lerpSpeed}
        color={color}
        autoAnimate={autoAnimate}
        particleVariance={particleVariance}
        rotationSpeed={rotationSpeed}
        depthFactor={depthFactor}
        pulseSpeed={pulseSpeed}
        particleShape={particleShape}
        fieldStrength={fieldStrength}
      />
    </Canvas>
  );
};

export default Antigravity;
