import { useState, useEffect, MouseEvent, useRef } from 'react';
import { Menu, X, Sun, Moon, Terminal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

interface MagneticLinkProps {
  children: React.ReactNode;
  href: string;
  active: boolean;
  onClick: (e: MouseEvent<HTMLAnchorElement>) => void;
  theme: 'light' | 'dark';
}

// Premium Magnetic Nav pill wrapper (Desktop-only magnetic & glow effect)
function MagneticNavLink({ children, href, active, onClick, theme }: MagneticLinkProps) {
  const elRef = useRef<HTMLAnchorElement>(null);
  const [coords, setCoords] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  // Disable magnetic shift on devices without pointer capabilities
  const handleMouseMove = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!elRef.current || window.innerWidth < 1024) return;
    const { clientX, clientY } = e;
    const { left, top, width, height } = elRef.current.getBoundingClientRect();
    const x = clientX - (left + width / 2);
    const y = clientY - (top + height / 2);
    // Smooth factor translation (mouse translate factor: 10% - 15%)
    setCoords({ x: x * 0.12, y: y * 0.12 });
  };

  const handleMouseLeave = () => {
    setCoords({ x: 0, y: 0 });
    setIsHovered(false);
  };

  return (
    <a
      ref={elRef}
      href={href}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      className="relative px-5 py-2.5 rounded-full font-sans text-sm font-medium transition-colors duration-200 flex items-center justify-center group/navitem outline-none select-none"
      style={{
        transform: `translate3d(${coords.x}px, ${coords.y}px, 0)`,
        color: active
          ? theme === 'dark' ? '#00D4FF' : '#2563EB'
          : theme === 'dark' ? '#cbd5e1' : '#475569',
      }}
    >
      {/* Animated active glowing pill (Behind text) */}
      {active && (
        <motion.span
          layoutId="activeNavPill"
          className="absolute inset-0 rounded-full -z-10"
          style={{
            background: theme === 'dark' 
              ? 'rgba(0, 212, 255, 0.08)' 
              : 'rgba(37, 99, 235, 0.06)',
            border: theme === 'dark' 
              ? '1px solid rgba(0, 212, 255, 0.2)' 
              : '1px solid rgba(37, 99, 235, 0.15)',
            boxShadow: theme === 'dark'
              ? '0 0 12px rgba(0, 212, 255, 0.15)'
              : '0 0 12px rgba(37, 99, 235, 0.08)'
          }}
          transition={{ type: 'spring', stiffness: 350, damping: 25 }}
        />
      )}

      {/* Interactive hover glowing accent and animated slide underline */}
      <span className="relative z-10 flex flex-col items-center">
        <span className="transition-transform duration-200 group-hover/navitem:scale-105">
          {children}
        </span>
        <span
          className={`absolute -bottom-1.5 left-0 w-full h-[2px] bg-gradient-to-r ${
            theme === 'dark' ? 'from-[#00D4FF] to-[#4F46E5]' : 'from-[#2563EB] to-[#4F46E5]'
          } rounded-full transform scale-x-0 group-hover/navitem:scale-x-100 transition-transform duration-300 origin-left`}
        />
      </span>
    </a>
  );
}

export default function Navbar({ theme, toggleTheme }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [scrollProgress, setScrollProgress] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const headerRef = useRef<HTMLElement>(null);

  // Monitor Scroll Activities: Scroll position, layout shrinking, Reading progress
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      setScrolled(scrollY > 20);

      // Simple active link checking
      const sections = ['home', 'about', 'timeline', 'skills', 'projects', 'contact'];
      const scrollPosition = scrollY + 180; // Shared uniform offset threshold

      let currentActive = 'home';
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          const top = rect.top + (window.pageYOffset || document.documentElement.scrollTop);
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            currentActive = section;
            break;
          }
        }
      }

      // Handle the bottom edge explicitly
      if (window.innerHeight + scrollY >= document.documentElement.scrollHeight - 100) {
        currentActive = 'contact';
      }
      setActiveSection(currentActive);

      // Track writing/reading scroll progress percentage at top edge
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        setScrollProgress((scrollY / totalHeight) * 100);
      } else {
        setScrollProgress(0);
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Trigger initial execution
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Sync mobile overlay state to pause / resume background animations & manage document body scrolling lock
  useEffect(() => {
    const event = new CustomEvent('mobile-menu-changed', { detail: { open: isOpen } });
    window.dispatchEvent(event);

    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const navLinks = [
    { name: 'Home', href: '#home', id: 'home' },
    { name: 'About', href: '#about', id: 'about' },
    { name: 'Experience & Education', href: '#timeline', id: 'timeline' },
    { name: 'Skills & Certifications', href: '#skills', id: 'skills' },
    { name: 'Projects', href: '#projects', id: 'projects' },
    { name: 'Contact', href: '#contact', id: 'contact' },
  ];

  const handleClick = (e: MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      const rect = element.getBoundingClientRect();
      const absoluteTop = rect.top + (window.pageYOffset || document.documentElement.scrollTop);
      const offsetTop = absoluteTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth',
      });
      window.history.pushState(null, '', href);
    }
    // Defer closing screen to enjoy transition timing smoothly
    setTimeout(() => {
      setIsOpen(false);
    }, 180);
  };

  const handleCloseOverlay = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      setIsOpen(false);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    if (window.innerWidth < 1024) return;
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  // Glassmorphism and specialized theme-adaptive shadows config
  const navbarStyle = scrolled
    ? theme === 'dark'
      ? {
          background: 'rgba(8, 12, 25, 0.75)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
          boxShadow: '0 0 20px rgba(0, 212, 255, 0.15)',
          height: '72px',
        }
      : {
          background: 'rgba(255, 255, 255, 0.75)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(255, 255, 255, 0.2)',
          boxShadow: '0 10px 30px rgba(37, 99, 235, 0.10)',
          height: '72px',
        }
    : {
        background: 'transparent',
        borderBottom: '1px solid transparent',
        boxShadow: 'none',
        height: '88px',
      };

  return (
    <motion.header
      ref={headerRef}
      id="main-header"
      initial={{ opacity: 0, y: -25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.3 }}
      style={navbarStyle}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="fixed top-0 left-0 w-full z-[1000] pointer-events-auto transition-all duration-300 flex items-center"
    >
      {/* Scroll Reading Progress Bar at very top of header */}
      <div 
        className="absolute top-0 left-0 h-[3px] transition-all duration-100 z-[1001]"
        style={{
          width: `${scrollProgress}%`,
          backgroundColor: theme === 'dark' ? '#00D4FF' : '#2563EB',
          boxShadow: theme === 'dark' 
            ? '0 0 10px #00D4FF, 0 0 5px #00D4FF' 
            : '0 0 10px #2563EB, 0 0 5px #2563EB'
        }}
      />

      {/* Premium Spotlight highlight follows mouse over header (Only on Desktop) */}
      {isHovered && window.innerWidth >= 1024 && (
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300 opacity-100 z-0"
          style={{
            background: `radial-gradient(
              circle 120px at ${mousePos.x}px ${mousePos.y}px,
              ${theme === 'dark' ? 'rgba(0, 212, 255, 0.08)' : 'rgba(37, 99, 235, 0.05)'},
              transparent
            )`
          }}
        />
      )}

      <div className="responsive-container w-full relative z-10">
        <div className="flex items-center justify-between">
          {/* Brand Logo with Rotate, Scale and Glow Hover Effect */}
          <a
            href="#home"
            onClick={(e) => handleClick(e, '#home')}
            className="flex items-center gap-2 group cursor-pointer shrink-0 transition-all duration-300 hover:scale-[1.05]"
            id="nav-logo"
          >
            <div 
              className="p-2 rounded-lg text-white transition-all duration-300 group-hover:rotate-6"
              style={{
                backgroundColor: theme === 'dark' ? '#00D4FF' : '#2563EB',
                boxShadow: theme === 'dark'
                  ? '0 0 15px rgba(0, 212, 255, 0.4)'
                  : '0 0 15px rgba(37, 99, 235, 0.3)'
              }}
            >
              <Terminal size={18} />
            </div>
            <span className="font-display font-bold text-lg text-slate-900 dark:text-white tracking-tight">
              AM.<span className="transition-colors duration-300" style={{ color: theme === 'dark' ? '#00D4FF' : '#2563EB' }}>dev</span>
            </span>
          </a>

          {/* Desktop Navigation Menu (With Magnetic spotlight and active slide pills) */}
          <nav className="hidden md:flex items-center gap-1" id="desktop-nav">
            {navLinks.map((link) => (
              <MagneticNavLink
                key={link.id}
                href={link.href}
                active={activeSection === link.id}
                onClick={(e) => handleClick(e, link.href)}
                theme={theme}
              >
                {link.name}
              </MagneticNavLink>
            ))}
          </nav>

          {/* Utils Section: Theme Toggle + Mobile Menu Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={toggleTheme}
              className="rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 transition-colors border border-transparent hover:border-slate-200 dark:hover:border-slate-700 h-10 w-10 flex items-center justify-center cursor-pointer"
              aria-label="Toggle Theme"
              id="theme-toggle-btn"
              style={{ minWidth: '40px', minHeight: '40px' }}
            >
              {theme === 'dark' ? (
                <Sun size={20} className="text-amber-400" />
              ) : (
                <Moon size={20} className="text-blue-600" />
              )}
            </button>

            {/* Mobile Menu Icon with responsive touch target sizing */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 md:hidden transition-colors border border-slate-200 dark:border-slate-800 flex flex-col justify-center items-center gap-1.5 w-10 h-10 cursor-pointer"
              aria-label="Toggle Menu"
              id="mobile-menu-toggle-btn"
              style={{ minWidth: '40px', minHeight: '40px' }}
            >
              <motion.span
                animate={isOpen ? { rotate: 45, y: 5 } : { rotate: 0, y: 0 }}
                transition={{ duration: 0.2 }}
                className="w-5 h-0.5 bg-current block rounded-full"
              />
              <motion.span
                animate={isOpen ? { opacity: 0 } : { opacity: 1 }}
                transition={{ duration: 0.2 }}
                className="w-5 h-0.5 bg-current block rounded-full"
              />
              <motion.span
                animate={isOpen ? { rotate: -45, y: -5 } : { rotate: 0, y: 0 }}
                transition={{ duration: 0.2 }}
                className="w-5 h-0.5 bg-current block rounded-full"
              />
            </button>
          </div>
        </div>
      </div>

      {/* Upgraded Premium Fullscreen Mobile Navigation Menu Overlay (z-index: 9999) */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ x: '100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '100%', opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              width: '100%',
              height: '100vh',
              zIndex: 9999,
              background: 'rgba(5, 10, 30, 0.95)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              overflowY: 'auto',
            }}
            onClick={handleCloseOverlay}
            className="md:hidden flex flex-col justify-center items-center p-6 text-white"
            id="mobile-nav-panel"
          >
            {/* Close Button on Top-Right - 48px touch target size & z-index: 10000 */}
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-6 right-6 z-[10000] p-3 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-full transition-all duration-350 flex items-center justify-center cursor-pointer"
              aria-label="Close Menu"
              style={{ minWidth: '48px', minHeight: '48px' }}
            >
              <X size={24} />
            </button>

            {/* Vertically centered, evenly spaced responsive container - gap 32px */}
            <div
              className="w-full max-w-md flex flex-col items-center justify-center my-auto px-4 select-none"
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '32px',
                justifyContent: 'center',
                alignItems: 'center',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {navLinks.map((link) => (
                <a
                  key={link.id}
                  href={link.href}
                  onClick={(e) => handleClick(e, link.href)}
                  className="w-full max-w-xs text-center flex items-center justify-center transition-all duration-300 py-3 px-6 rounded-2xl hover:bg-white/5 hover:scale-105 active:scale-95"
                  style={{
                    minWidth: '220px',
                    minHeight: '48px',
                    color: activeSection === link.id ? '#00D4FF' : '#cbd5e1',
                    fontWeight: activeSection === link.id ? 700 : 500,
                    fontSize: '1.25rem',
                  }}
                >
                  <span className="relative">
                    {link.name}
                    {activeSection === link.id && (
                      <motion.span
                        layoutId="activeSubIndicatorMobile"
                        className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-8 h-1 bg-[#00D4FF] rounded-full"
                        style={{ boxShadow: '0 0 10px #00D4FF' }}
                        transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                      />
                    )}
                  </span>
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
