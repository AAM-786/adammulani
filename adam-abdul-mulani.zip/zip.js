import AdmZip from 'adm-zip';
import fs from 'fs';
import path from 'path';

async function createProjectZip() {
  const rootDir = process.cwd();
  const zipProDir = path.join(rootDir, 'Zip Pro');
  
  // Ensure the "Zip Pro" directory exists
  if (!fs.existsSync(zipProDir)) {
    fs.mkdirSync(zipProDir, { recursive: true });
  }

  const zip = new AdmZip();

  // Add files & directories we want to include
  const entriesToZip = [
    'src',
    'assets',
    'index.html',
    'package.json',
    'package-lock.json',
    'server.ts',
    'tsconfig.json',
    'vite.config.ts',
    '.env.example',
    'metadata.json'
  ];

  for (const entry of entriesToZip) {
    const entryPath = path.join(rootDir, entry);
    if (fs.existsSync(entryPath)) {
      const stat = fs.statSync(entryPath);
      if (stat.isDirectory()) {
        zip.addLocalFolder(entryPath, entry);
      } else {
        zip.addLocalFile(entryPath);
      }
    }
  }

  const outputZipPath = path.join(zipProDir, 'project.zip');
  zip.writeZip(outputZipPath);
  console.log(`Successfully zipped project. Saved to: ${outputZipPath}`);
}

createProjectZip().catch((err) => {
  console.error('Zipping failed:', err);
  process.exit(1);
});
