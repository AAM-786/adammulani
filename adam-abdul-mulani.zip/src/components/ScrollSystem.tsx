import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUp, Flame, Trophy, Mail, FileText, Linkedin, Sparkles, X } from 'lucide-react';
import { personalInfo } from '../data';

// Definition of Sections tracked on the page
const SECTIONS = [
  { id: 'home', label: 'Hero' },
  { id: 'about', label: 'About Adam' },
  { id: 'timeline', label: 'Experience & Edu' },
  { id: 'skills', label: 'Skills & Certs' },
  { id: 'projects', label: 'Projects & Milestones' },
  { id: 'contact', label: 'Contact Coordinates' }
];

export default function ScrollSystem() {
  const [scrollPercent, setScrollPercent] = useState(0);
  const [activeSection, setActiveSection] = useState('home');
  const [completedSections, setCompletedSections] = useState<string[]>(['home']);
  const [hudMessage, setHudMessage] = useState('Starting the Journey');
  const [progressLabel, setProgressLabel] = useState('Exploring Portfolio');
  
  // Back to top rocket simulation
  const [isRocketLaunching, setIsRocketLaunching] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const celebrationDismissedRef = useRef(false);
  
  // Achievement/Milestone Toast state array
  const [activeToasts, setActiveToasts] = useState<{ id: string; title: string; detail: string }[]>([]);
  const seenMilestones = useState<Set<string>>(() => new Set())[0];

  useEffect(() => {
    const handleScroll = () => {
      // 1. Calculate Scroll Percentage
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (scrollHeight <= 0) return;
      const currentScroll = window.scrollY;
      const percent = Math.min(100, Math.max(0, Math.round((currentScroll / scrollHeight) * 100)));
      setScrollPercent(percent);

      // 2. Determine Active Section
      let currentActive = 'home';
      const scrollPosition = window.scrollY + 180; // Shared uniform offset threshold

      for (const sect of SECTIONS) {
        const el = document.getElementById(sect.id);
        if (el) {
          const rect = el.getBoundingClientRect();
          const top = rect.top + (window.pageYOffset || document.documentElement.scrollTop);
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            currentActive = sect.id;
            break;
          }
        }
      }
      
      // Handle the bottom edge explicitly
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 100) {
        currentActive = 'contact';
      }

      setActiveSection(currentActive);

      // 3. Update Completed Sections List
      const activeIdx = SECTIONS.findIndex(s => s.id === currentActive);
      const newlyCompleted = SECTIONS.slice(0, activeIdx + 1).map(s => s.id);
      setCompletedSections(prev => {
        const union = new Set([...prev, ...newlyCompleted]);
        return Array.from(union);
      });

      // 4. Update Progress Labels and Status Messages based on Scroll Ranges
      if (percent < 20) {
        setHudMessage('Starting the Journey');
        setProgressLabel('Exploring Portfolio');
      } else if (percent >= 20 && percent < 40) {
        setHudMessage('Exploring Academic Excellence');
        setProgressLabel('Learning About Adam');
      } else if (percent >= 40 && percent < 60) {
        setHudMessage('Discovering Professional Experience');
        setProgressLabel('Reviewing Experience');
      } else if (percent >= 60 && percent < 80) {
        setHudMessage('Unlocking Technical Skills');
        setProgressLabel('Checking Domains');
      } else if (percent >= 80 && percent < 95) {
        setHudMessage('Reviewing Projects & Achievements');
        setProgressLabel('Assessing Sandbox Artifacts');
      } else {
        setHudMessage('Ready to Connect');
        setProgressLabel('Completing Integration Flow');
      }

      // 5. Trigger Completion Celebration when hitting bottom
      if (percent >= 98) {
        if (!celebrationDismissedRef.current) {
          setShowCelebration(true);
        }
      } else {
        setShowCelebration(false);
        if (percent < 90) {
          celebrationDismissedRef.current = false;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Helper to trigger specific popups when a user hits corresponding sections
  const triggerMilestonePopups = (sectId: string) => {
    // Scroll Milestone HUD Toasts disabled as requested
  };

  const scrollToTop = () => {
    setIsRocketLaunching(true);
    
    const startY = window.pageYOffset || document.documentElement.scrollTop;
    const startTime = performance.now();
    const duration = 1000; // 1000ms is perfectly in the 800-1200ms range per request

    const easeInOutQuad = (t: number, b: number, c: number, d: number) => {
      t /= d / 2;
      if (t < 1) return (c / 2) * t * t + b;
      t--;
      return (-c / 2) * (t * (t - 2) - 1) + b;
    };

    const animateScroll = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      if (elapsed < duration) {
        const nextY = easeInOutQuad(elapsed, startY, -startY, duration);
        window.scrollTo(0, nextY);
        requestAnimationFrame(animateScroll);
      } else {
        window.scrollTo(0, 0);
        setIsRocketLaunching(false);
        // Clear hash on return to home/top
        window.history.pushState(null, '', '#home');
      }
    };

    requestAnimationFrame(animateScroll);
  };

  const handleSectionClick = (sectId: string) => {
    const el = document.getElementById(sectId);
    if (el) {
      const rect = el.getBoundingClientRect();
      const absoluteTop = rect.top + (window.pageYOffset || document.documentElement.scrollTop);
      const offsetTop = absoluteTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
      window.history.pushState(null, '', `#${sectId}`);
    }
  };

  // Circular calculations for progress button
  const radius = 24;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (scrollPercent / 100) * circumference;

  return (
    <>
      {/* 1. FIXED TOP GRADIENT STREAM PROGRESS BAR */}
      <div className="fixed top-0 left-0 w-full h-[5px] bg-slate-200/20 dark:bg-slate-900/40 z-[100] no-print pointer-events-none">
        <div
          className="h-full bg-gradient-to-r from-blue-600 via-cyan-400 to-purple-650 shadow-[0_0_12px_rgba(6,182,212,0.8)] transition-all duration-100"
          style={{ width: `${scrollPercent}%` }}
        />
      </div>

      {/* 2. FLOATING RUNNING READING PROGRESS CAPTION */}
      <div className="fixed top-[70px] right-6 z-40 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full border border-slate-200/50 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md shadow-xs no-print select-none">
        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
        <span className="font-mono text-[9px] font-bold text-slate-500 dark:text-slate-400 tracking-wider uppercase">
          {progressLabel} &mdash; <span className="text-blue-600 dark:text-cyan-400 font-extrabold">{scrollPercent}%</span>
        </span>
      </div>

      {/* 3. FLOAT VERTICAL DESKTOP DOCK NAVIGATION */}
      <div className="fixed left-6 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col gap-4 p-4 rounded-3xl border border-slate-200/40 dark:border-slate-800 bg-white/60 dark:bg-slate-950/40 backdrop-blur-lg shadow-sm no-print">
        <div className="font-mono text-[8px] font-black uppercase text-slate-400 dark:text-slate-500 tracking-widest text-center writing-mode mb-2 pb-2 border-b border-slate-200/50 dark:border-slate-800">
          SYSTEM CHART
        </div>
        
        {SECTIONS.map((sect) => {
          const isActive = activeSection === sect.id;
          const isCompleted = completedSections.includes(sect.id);

          return (
            <button
              key={sect.id}
              onClick={() => handleSectionClick(sect.id)}
              className="group relative flex items-center gap-3 cursor-pointer text-left"
              id={`deck-dock-${sect.id}`}
            >
              {/* Checkpoint Dot Selector */}
              <div
                className={`w-3.5 h-3.5 rounded-full border-2 transition-all flex items-center justify-center ${
                  isActive
                    ? 'border-blue-600 bg-blue-600 dark:border-cyan-400 dark:bg-cyan-500 scale-125 glow-cyan'
                    : isCompleted
                    ? 'border-blue-500/70 bg-blue-500/40 dark:border-cyan-500/50 dark:bg-cyan-500/10'
                    : 'border-slate-300 dark:border-slate-800 bg-transparent'
                }`}
              >
                {isActive && (
                  <span className="w-1 h-1 bg-white dark:bg-slate-950 rounded-full" />
                )}
              </div>

              {/* Tooltip labeling hover trigger */}
              <span className={`absolute left-7 px-2.5 py-1 text-[10px] font-mono tracking-wider font-semibold uppercase rounded-md shadow-xs opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all duration-200 whitespace-nowrap bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 pointer-events-none`}>
                {sect.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* 4. CIRCULAR BACK TO TOP LAUNCH BUTTON - Conditional rendering hides it near top */}
      <AnimatePresence>
        {scrollPercent > 10 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.3 }}
            className="fixed bottom-6 right-6 z-[9998] no-print"
            id="circular-top-floater"
          >
            <button
              onClick={scrollToTop}
              disabled={isRocketLaunching}
              className={`relative w-14 h-14 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-lg overflow-visible ${
                isRocketLaunching
                  ? 'bg-blue-600 dark:bg-cyan-500 text-white animate-bounce'
                  : 'glass-panel text-slate-800 dark:text-white border border-slate-300 dark:border-slate-800 hover:scale-105 active:scale-95'
              }`}
              aria-label="Ignite return trajectory to top"
            >
              {/* Radial SVG Track */}
              <svg className="absolute inset-0 w-14 h-14 -rotate-90">
                <circle
                  cx="28"
                  cy="28"
                  r={radius}
                  className="stroke-slate-200/50 dark:stroke-slate-800/40 fill-none"
                  strokeWidth="3.5"
                />
                <circle
                  cx="28"
                  cy="28"
                  r={radius}
                  className="stroke-blue-600 dark:stroke-cyan-400 fill-none transition-all duration-100"
                  strokeWidth="3.5"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                />
              </svg>

              {/* Icon overlay showing status: Show critical fire symbol (Flame) at 100% progress */}
              {isRocketLaunching || scrollPercent >= 99 ? (
                <div className="flex flex-col items-center justify-center text-orange-500 dark:text-cyan-400">
                  <Flame size={22} className="animate-bounce text-orange-500 dark:text-amber-400" />
                  <span className="text-[7px] font-mono font-black mt-0.5 text-orange-600 dark:text-cyan-400 uppercase tracking-widest">FIRE</span>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center">
                  <ArrowUp size={16} />
                  <span className="text-[8px] font-mono font-extrabold mt-0.5">{scrollPercent}%</span>
                </div>
              )}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Removed scroll toasts component */}

      {/* 6. CELEBRATION DISMISSABLE FULL SCREEN END BANNER */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.45 }}
            className="fixed bottom-[100px] left-1/2 -translate-x-1/2 z-40 max-w-lg w-[calc(100vw-2.5rem)] px-6 py-5 rounded-2xl glass-panel text-center border border-emerald-500/30 shadow-[0_15px_45px_rgba(16,185,129,0.15)] no-print"
            id="portfolio-celebration-banner"
          >
            {/* Elegant Close Button targeting the cross icon request */}
            <button
              onClick={() => {
                celebrationDismissedRef.current = true;
                setShowCelebration(false);
              }}
              className="absolute top-3 right-3 p-1.5 rounded-full text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-900/80 transition-colors cursor-pointer z-10"
              aria-label="Close celebration message"
              id="close-celebration-popup"
            >
              <X size={15} />
            </button>

            <div className="absolute top-4 right-11 flex gap-1 items-center">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            </div>

            <div className="flex justify-center mb-2 text-emerald-500 dark:text-emerald-400">
              <Sparkles size={28} className="animate-bounce" />
            </div>

            <h3 className="font-display font-black text-sm tracking-wide text-slate-900 dark:text-white uppercase">
              🎉 Portfolio Fully Explored
            </h3>
            <p className="font-sans text-xs text-slate-500 dark:text-slate-400 mt-1 leading-snug">
              Thank you for visiting! You have mapped all academic trajectories and milestones. Ready to build the future together.
            </p>

            {/* Quick response action buttons */}
            <div className="flex gap-2 mt-4 justify-center">
              <button
                onClick={() => handleSectionClick('contact')}
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium text-[10px] uppercase transition-all cursor-pointer flex items-center gap-1 shadow-sm"
              >
                <Mail size={11} />
                <span>Contact Me</span>
              </button>

              <button
                onClick={() => {
                  window.dispatchEvent(new CustomEvent('open-resume-modal'));
                }}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900 text-slate-700 dark:text-slate-300 font-medium text-[10px] uppercase transition-all cursor-pointer flex items-center gap-1 shadow-sm"
              >
                <FileText size={11} />
                <span>Resume Feed</span>
              </button>

              <a
                href={personalInfo.socials.linkedin}
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-slate-200 text-white font-medium text-[10px] uppercase transition-all flex items-center gap-1 shadow-sm"
              >
                <Linkedin size={11} />
                <span>LinkedIn Connect</span>
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
