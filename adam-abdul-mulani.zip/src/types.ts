export interface Education {
  id: string;
  degree: string;
  institution: string;
  universityOrBoard: string;
  duration: string;
  status?: string;
  percentageOrGpa?: string;
  description?: string;
  highlights?: string[];
}

export interface Experience {
  id: string;
  title: string;
  company: string;
  duration: string;
  role: string;
  responsibilities: string[];
  achievements: string[];
}

export interface Skill {
  name: string;
  level: number; // 0-100 for visual skill bars
}

export interface SkillCategory {
  category: string;
  skills: Skill[];
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  organizedBy?: string;
  year?: string;
}

export interface Project {
  id: string;
  title: string;
  technologies: string[];
  description: string;
  category: 'ai' | 'security' | 'web' | 'all';
  githubUrl?: string;
  demoUrl?: string;
}

export interface Achievement {
  id: string;
  title: string;
  detail: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  timestamp: string;
}
