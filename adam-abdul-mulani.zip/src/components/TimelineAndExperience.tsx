import { motion } from 'motion/react';
import { Briefcase, GraduationCap, Calendar, CheckCircle2, ChevronRight, Bookmark } from 'lucide-react';
import { educationList, experienceList } from '../data';

export default function TimelineAndExperience() {
  return (
    <section
      id="timeline"
      className="py-24 bg-slate-50 dark:bg-slate-950 transition-colors border-y border-slate-100 dark:border-slate-900 scroll-mt-20"
    >
      <div className="responsive-container">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20 no-print">
          <h2 className="font-display font-medium text-xs tracking-widest text-blue-600 dark:text-cyan-400 uppercase">
            Trajectory
          </h2>
          <p className="mt-2 font-display font-bold text-3xl sm:text-4xl text-slate-900 dark:text-white tracking-tight">
            Qualifications & Internships
          </p>
          <div className="mt-4 w-12 h-1 bg-gradient-to-r from-blue-600 to-cyan-500 mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* PROFESSIONAL EXPERIENCE COLUMN */}
          <div className="space-y-12">
            <h3 className="font-display font-bold text-2xl text-slate-900 dark:text-white flex items-center gap-3 border-b pb-4 border-slate-200/65 dark:border-slate-900">
              <span className="p-2 bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-cyan-400 rounded-xl">
                <Briefcase size={20} />
              </span>
              <span>Internship Work Experience</span>
            </h3>

            <div className="relative border-l-2 border-blue-100 dark:border-slate-800 ml-4 pl-8 space-y-12" id="experience-timeline">
              {experienceList.map((exp, index) => (
                <div key={exp.id} className="relative group" id={`experience-card-${exp.id}`}>
                  {/* Outer point */}
                  <span className="absolute -left-[41px] top-1.5 flex items-center justify-center w-6 h-6 rounded-full bg-white dark:bg-slate-950 border-2 border-blue-600 dark:border-cyan-400 z-10 transition-transform group-hover:scale-110">
                    <span className="w-2 h-2 bg-blue-600 dark:bg-cyan-400 rounded-full" />
                  </span>

                  {/* Date Capsule */}
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400 text-xs font-semibold mb-4 border border-transparent dark:border-slate-800">
                    <Calendar size={12} />
                    <span>{exp.duration}</span>
                  </div>

                  {/* Career Content Card */}
                  <h4 className="font-display font-bold text-lg sm:text-xl text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-cyan-400 transition-colors">
                    {exp.title}
                  </h4>
                  <p className="font-sans font-medium text-sm text-slate-500 dark:text-slate-400">
                    {exp.company}
                  </p>
                  <p className="font-mono text-xs text-blue-600 dark:text-cyan-400/80 mt-1">
                    {exp.role}
                  </p>

                  {/* Responsibilities list */}
                  <div className="mt-4 space-y-2.5">
                    <p className="text-xs font-mono tracking-widest text-slate-400 dark:text-slate-500 uppercase font-bold">
                      Key Core Contributions
                    </p>
                    <ul className="space-y-2">
                      {exp.responsibilities.slice(0, 4).map((resp, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-300">
                          <ChevronRight size={14} className="text-blue-600 dark:text-cyan-500 flex-shrink-0 mt-1" />
                          <span>{resp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Accomplishment highlights */}
                  <div className="mt-4 pt-4 border-t border-dashed border-slate-200/50 dark:border-slate-800/80">
                    <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider mb-2">
                      <CheckCircle2 size={12} />
                      <span>Internship Accomplishments</span>
                    </div>
                    <ul className="space-y-1.5">
                      {exp.achievements.map((ach, idx) => (
                        <li key={idx} className="text-xs text-slate-500 dark:text-slate-400 flex items-start gap-2">
                          <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mt-1.5 flex-shrink-0" />
                          <span>{ach}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ACADEMIC TIMELINE COLUMN */}
          <div className="space-y-12">
            <h3 className="font-display font-bold text-2xl text-slate-900 dark:text-white flex items-center gap-3 border-b pb-4 border-slate-200/65 dark:border-slate-900">
              <span className="p-2 bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-cyan-400 rounded-xl">
                <GraduationCap size={20} />
              </span>
              <span>Educational Timeline</span>
            </h3>

            <div className="relative border-l-2 border-blue-100 dark:border-slate-800 ml-4 pl-8 space-y-12" id="education-timeline">
              {educationList.map((edu, index) => (
                <div key={edu.id} className="relative group" id={`education-card-${edu.id}`}>
                  {/* Point */}
                  <span className="absolute -left-[41px] top-1.5 flex items-center justify-center w-6 h-6 rounded-full bg-white dark:bg-slate-950 border-2 border-blue-600 dark:border-cyan-400 z-10 transition-transform group-hover:scale-110">
                    <span className="w-2 h-2 bg-blue-600 dark:bg-cyan-400 rounded-full" />
                  </span>

                  {/* Date capsule */}
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400 text-xs font-semibold mb-4 border border-transparent dark:border-slate-800">
                    <Calendar size={12} />
                    <span>{edu.duration}</span>
                  </div>

                  {/* Academic Content */}
                  <h4 className="font-display font-bold text-lg sm:text-xl text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-cyan-400 transition-colors">
                    {edu.degree}
                  </h4>
                  <p className="font-sans font-medium text-sm text-slate-600 dark:text-slate-300">
                    {edu.institution}
                  </p>
                  <p className="font-mono text-xs text-slate-400 dark:text-slate-500">
                    {edu.universityOrBoard}
                  </p>

                  {/* Grade status indicator */}
                  {edu.status || edu.percentageOrGpa ? (
                    <div className="mt-2.5 inline-flex items-center gap-2 px-2.5 py-1 rounded bg-blue-50/50 dark:bg-cyan-950/20 text-xs font-semibold text-blue-700 dark:text-cyan-400 border border-blue-100/30 dark:border-cyan-900/40">
                      <Bookmark size={12} />
                      <span>{edu.status ? `Status: ${edu.status}` : `Result: ${edu.percentageOrGpa}`}</span>
                    </div>
                  ) : null}

                  {/* Description */}
                  {edu.description && (
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-3 leading-relaxed">
                      {edu.description}
                    </p>
                  )}

                  {/* Course Topics bullet tags */}
                  {edu.highlights && edu.highlights.length > 0 && (
                    <div className="mt-4">
                      <span className="text-xs font-mono font-bold uppercase text-slate-400 tracking-wider">
                        Core Subjects & Focus
                      </span>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {edu.highlights.map((tag) => (
                          <span
                            key={tag}
                            className="px-2.5 py-1 text-xs rounded-lg border border-slate-200/50 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-350 shadow-xs"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
