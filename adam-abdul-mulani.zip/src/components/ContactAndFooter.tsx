import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, MapPin, Send, Check, Linkedin, Github, Instagram, Twitter, ExternalLink, RefreshCw, Terminal } from 'lucide-react';
import { personalInfo } from '../data';
import { ContactMessage } from '../types';

export default function ContactAndFooter() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [showInbox, setShowInbox] = useState(false);
  const [showEmailPrompt, setShowEmailPrompt] = useState(false);

  // Load message logs from localStorage on mount (Simulating real database feed)
  useEffect(() => {
    const stored = localStorage.getItem('adam_portfolio_messages');
    if (stored) {
      try {
        setMessages(JSON.parse(stored));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name || !email || !subject || !message) return;

    // Trigger prompt to verify if user wants to construct and trigger a real mailto redirect
    setShowEmailPrompt(true);
  };

  const handleConfirmPrompt = (redirect: boolean) => {
    setShowEmailPrompt(false);
    setIsSubmitting(true);

    if (redirect) {
      // Build proper mailto link template to trigger physical email app clients
      const mailtoUrl = `mailto:${personalInfo.email}?subject=${encodeURIComponent(
        subject
      )}&body=${encodeURIComponent(
        `Full Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`
      )}`;
      window.location.href = mailtoUrl;
    }

    // Process storage logging asynchronously
    setTimeout(() => {
      const newMessage: ContactMessage = {
        id: `msg-${Date.now()}`,
        name,
        email,
        subject,
        message,
        timestamp: new Date().toLocaleString()
      };

      const updated = [newMessage, ...messages];
      setMessages(updated);
      localStorage.setItem('adam_portfolio_messages', JSON.stringify(updated));

      setIsSubmitting(false);
      setIsSuccess(true);

      // Clean inputs
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');

      // Auto dismiss success statement
      setTimeout(() => {
        setIsSuccess(false);
      }, 5000);
    }, 1200);
  };

  const clearInbox = () => {
    localStorage.removeItem('adam_portfolio_messages');
    setMessages([]);
  };

  const socialLinksConfig = [
    { name: 'LinkedIn', icon: <Linkedin size={18} />, url: personalInfo.socials.linkedin },
    { name: 'GitHub', icon: <Github size={18} />, url: personalInfo.socials.github },
    { name: 'Instagram', icon: <Instagram size={18} />, url: personalInfo.socials.instagram },
    { name: 'Twitter/X', icon: <Twitter size={18} />, url: personalInfo.socials.twitter },
    { name: 'ACESSE', icon: <ExternalLink size={18} />, url: personalInfo.portfolioUrl },
  ];

  return (
    <footer id="contact" className="bg-slate-900 text-slate-100 transition-colors pt-24 pb-12 relative overflow-hidden scroll-mt-20">
      
      {/* Decorative cosmic elements */}
      <div className="absolute top-[20%] right-[10%] w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[10%] left-[5%] w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="responsive-container relative z-10">
        
        {/* HEADER */}
        <div className="text-center max-w-3xl mx-auto mb-16 no-print">
          <h2 className="font-display font-medium text-xs tracking-widest text-cyan-400 uppercase">
            Let&apos;s Network
          </h2>
          <p className="mt-2 font-display font-bold text-3xl sm:text-4xl text-white tracking-tight">
            Start A Conversation
          </p>
          <div className="mt-4 w-12 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-20 items-stretch" id="contact-outer-grid">
          
          {/* LEFT COLUMN: COORDINATES & SOCIAL LINKS */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-12">
            <div className="space-y-6">
              <h3 className="font-display font-bold text-xl text-white">
                Contact Coordinates
              </h3>
              <p className="text-sm font-sans text-slate-400 leading-relaxed">
                Connect with Adam for job opportunities, collaborative computer networking, AI algorithms or freelance consultancies.
              </p>

              <div className="space-y-4 pt-4" id="contact-address-links">
                <div className="flex items-center gap-3.5" id="coord-email">
                  <span className="p-2.5 bg-slate-800 text-cyan-400 rounded-xl border border-slate-700/50">
                    <Mail size={18} />
                  </span>
                  <div>
                    <span className="block text-xs text-slate-500 font-mono uppercase tracking-wider">Mail Coordinates</span>
                    <a href={`mailto:${personalInfo.email}`} className="text-sm font-semibold hover:text-cyan-400 transition-colors">
                      {personalInfo.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-3.5" id="coord-location">
                  <span className="p-2.5 bg-slate-800 text-cyan-400 rounded-xl border border-slate-700/50">
                    <MapPin size={18} />
                  </span>
                  <div>
                    <span className="block text-xs text-slate-500 font-mono uppercase tracking-wider">Resident Location</span>
                    <span className="text-sm font-semibold text-slate-350">
                      {personalInfo.location}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Grid */}
            <div className="space-y-4">
              <h4 className="font-mono text-xs font-bold uppercase tracking-widest text-slate-500">
                Professional Handles
              </h4>
              <div className="flex flex-wrap gap-2.5" id="social-handles-bar">
                {socialLinksConfig.map((soc) => (
                  <a
                    key={soc.name}
                    href={soc.url}
                    target="_blank"
                    referrerPolicy="no-referrer"
                    rel="noreferrer"
                    className="p-3 bg-slate-850 hover:bg-slate-800 rounded-xl text-slate-300 hover:text-cyan-400 border border-slate-850 transition-all cursor-pointer hover:scale-105"
                    aria-label={`Connect on ${soc.name}`}
                    title={soc.name}
                  >
                    {soc.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: CONTACT FORM & LIVE INBOX SIMULATOR */}
          <div className="lg:col-span-7">
            <div className="bg-slate-950/40 border border-slate-800 p-6 sm:p-8 rounded-3xl" id="contact-form-panel">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display font-medium text-lg text-white">
                  Message Dispatch Engine
                </h3>
                
                {/* Inbox toggle indicator */}
                {messages.length > 0 && (
                  <button
                    onClick={() => setShowInbox(!showInbox)}
                    className="px-3 py-1.5 rounded-lg bg-teal-500/10 hover:bg-teal-500/20 text-teal-400 text-xs font-mono font-semibold transition-colors flex items-center gap-1.5 cursor-pointer border border-teal-500/20"
                    id="toggle-inbox-simulator"
                  >
                    <Terminal size={12} />
                    <span>Inbox ({messages.length})</span>
                  </button>
                )}
              </div>

              {!showInbox ? (
                // Standalone form representation
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label htmlFor="fullName" className="text-xs font-mono text-slate-400">Full Name *</label>
                      <input
                        type="text"
                        id="fullName"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Example"
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-800 hover:border-slate-700 focus:border-cyan-400 text-sm text-slate-100 rounded-xl outline-none transition-colors"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label htmlFor="emailAddress" className="text-xs font-mono text-slate-400">Email Address *</label>
                      <input
                        type="email"
                        id="emailAddress"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="example@gmail.com"
                        className="w-full px-4 py-3 bg-slate-900 border border-slate-800 hover:border-slate-700 focus:border-cyan-400 text-sm text-slate-100 rounded-xl outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="msgSubject" className="text-xs font-mono text-slate-400">Subject *</label>
                    <input
                      type="text"
                      id="msgSubject"
                      required
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="Project collaboration / Freelance opportunity"
                      className="w-full px-4 py-3 bg-slate-900 border border-slate-800 hover:border-slate-700 focus:border-cyan-400 text-sm text-slate-100 rounded-xl outline-none transition-colors"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="msgBody" className="text-xs font-mono text-slate-400">Your Message *</label>
                    <textarea
                      id="msgBody"
                      required
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Hi Adam, I would love to connect to discuss potential projects and smart engineering collaborations..."
                      className="w-full px-4 py-3 bg-slate-900 border border-slate-800 hover:border-slate-700 focus:border-cyan-400 text-sm text-slate-100 rounded-xl outline-none transition-colors resize-none"
                    />
                  </div>

                  {/* Submission status feedback blocks */}
                  <AnimatePresence>
                    {isSuccess && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="p-3.5 rounded-xl bg-teal-500/10 text-teal-400 border border-teal-500/20 text-xs font-semibold flex items-center gap-2"
                        id="contact-form-success"
                      >
                        <Check size={16} />
                        <span>Transmission Complete! Your message has been archived in the Browser Simulator Inbox. Click &apos;Inbox&apos; at the top-right to inspect!</span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs tracking-widest uppercase dark:bg-cyan-500 dark:text-slate-950 dark:hover:bg-cyan-600 flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:bg-slate-850 disabled:text-slate-500 disabled:cursor-not-allowed hover:-translate-y-0.5 active:scale-95"
                    id="dispatch-message-btn"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" />
                        <span>Routing Feed...</span>
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        <span>Send Message</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                // inbox drawer container
                <div className="space-y-4" id="inbox-logs-panel">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-mono text-teal-400 uppercase tracking-widest">
                      Local Storage Simulated Inbox
                    </p>
                    <button
                      onClick={clearInbox}
                      className="text-[10px] font-mono text-rose-400 hover:text-rose-350 underline transition-colors cursor-pointer"
                    >
                      Reset Inbox Logs
                    </button>
                  </div>

                  <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
                    {messages.map((msg) => (
                      <div key={msg.id} className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                        <div className="flex justify-between items-start text-xs font-mono">
                          <span className="font-bold text-slate-200">{msg.name}</span>
                          <span className="text-slate-500">{msg.timestamp}</span>
                        </div>
                        <p className="text-xs font-semibold text-slate-300">
                          Subj: {msg.subject}
                        </p>
                        <p className="text-xs text-slate-400 font-light border-l border-slate-700 pl-2">
                          {msg.message}
                        </p>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => setShowInbox(false)}
                    className="w-full py-2 rounded-lg border border-slate-800 hover:border-slate-700 text-slate-400 text-xs font-mono transition-colors cursor-pointer"
                    id="quit-inbox-btn"
                  >
                    Return to Form Dispatcher
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* BOTTOM DIV: POLISHED FOOTER DECAL */}
        <div className="pt-12 border-t border-slate-800/80 flex flex-col md:flex-row items-center justify-between text-center md:text-left gap-6 font-sans">
          <div className="space-y-1.5">
            <h4 className="font-display font-medium text-lg text-white">
              {personalInfo.name}
            </h4>
            <span className="block text-xs font-mono text-cyan-400/80">
              {personalInfo.title}
            </span>
            <p className="text-xs text-slate-500 italic max-w-sm">
              &ldquo;{personalInfo.name ? "Building intelligent solutions for tomorrow." : ""}&rdquo;
            </p>
          </div>

          <div className="text-right flex flex-col items-center md:items-end gap-1.5">
            <p className="text-xs text-slate-400">
              © {new Date().getFullYear()} Adam Abdul Mulani. All Rights Reserved.
            </p>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block">
              Mumbai University Graduate Candidate
            </span>
          </div>
        </div>

      </div>

      {/* Dynamic confirmation mail client redirect overlay dialog */}
      <AnimatePresence>
        {showEmailPrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-100 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-6 pointer-events-auto"
            id="confirm-email-modal"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className="max-w-md w-full bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-2xl relative text-left"
            >
              <div className="absolute top-4 right-4">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping absolute" />
                <span className="w-2 h-2 rounded-full bg-cyan-400" />
              </div>

              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 bg-blue-600/10 dark:bg-cyan-500/10 text-cyan-400 rounded-xl">
                  <Mail size={22} className="animate-pulse" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-sm tracking-wide text-white uppercase">
                    Confirm Dispatch Preference
                  </h3>
                  <p className="text-[10px] font-mono text-slate-400 uppercase">
                    Redirect coordinates check
                  </p>
                </div>
              </div>

              <div className="space-y-3 font-sans text-xs text-slate-300 leading-relaxed mb-6 bg-slate-950/40 p-4 rounded-xl border border-slate-850">
                <p>
                  Would you also like to <strong>redirect and load this message directly in your device&apos;s email client</strong> to send an official electronic mail?
                </p>
                <p className="text-[10px] font-mono text-slate-500 border-t border-slate-800/60 pt-2">
                  <span className="text-cyan-400 font-extrabold">&gt; YES:</span> Opens local email client &amp; stores message in portfolio simulator.
                  <br />
                  <span className="text-rose-450 font-extrabold">&gt; NO:</span> Stores message in dashboard inbox simulator only. No client redirection.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => handleConfirmPrompt(true)}
                  className="flex-1 py-3 text-xs font-mono font-bold uppercase tracking-wider rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white cursor-pointer hover:shadow-lg transition-all active:scale-95 text-center border-none"
                  id="confirm-redirect-yes"
                >
                  Yes
                </button>
                <button
                  type="button"
                  onClick={() => handleConfirmPrompt(false)}
                  className="flex-1 py-3 text-xs font-mono font-bold uppercase tracking-wider rounded-xl border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer transition-all active:scale-95 text-center"
                  id="confirm-redirect-no"
                >
                  No
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </footer>
  );
}
