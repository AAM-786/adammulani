import { motion } from 'motion/react';
import { Globe, MapPin, Mail, GraduationCap, Printer } from 'lucide-react';
import { personalInfo } from '../data';

export default function AboutAndInfo() {
  const handlePrint = () => {
    window.dispatchEvent(new CustomEvent('open-resume-modal'));
  };

  return (
    <section id="about" className="py-24 bg-white dark:bg-slate-900 transition-colors scroll-mt-20">
      <div className="responsive-container">
        
        {/* Print-Only Professional Resume Header & Blueprint Layout */}
        <div className="hidden print:block font-sans text-slate-900 border-b pb-6 mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold uppercase tracking-tight">{personalInfo.name}</h1>
              <p className="text-blue-600 font-medium text-sm mt-1">{personalInfo.title}</p>
              <p className="text-slate-500 text-xs mt-2 max-w-xl">{personalInfo.bio}</p>
            </div>
            <div className="text-right text-xs text-slate-500 space-y-1">
              <p className="flex items-center justify-end gap-1.5 font-medium"><MapPin size={12} /> {personalInfo.location}</p>
              <p className="flex items-center justify-end gap-1.5"><Mail size={12} /> {personalInfo.email}</p>
              <p className="flex items-center justify-end gap-1.5"><Globe size={12} /> {personalInfo.portfolioUrl}</p>
            </div>
          </div>
        </div>

        {/* Multi-Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 no-print">
          <h2 className="font-display font-medium text-xs tracking-widest text-blue-600 dark:text-cyan-400 uppercase">
            Professional Overview
          </h2>
          <p className="mt-2 font-display font-bold text-3xl sm:text-4xl text-slate-900 dark:text-white tracking-tight">
            About Adam Abdul Mulani
          </p>
          <div className="mt-4 w-12 h-1 bg-gradient-to-r from-blue-600 to-cyan-500 mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-1 gap-12 items-start" id="about-content">
          
          {/* Detailed Biography Column */}
          <div className="lg:col-span-12 max-w-4xl mx-auto w-full space-y-6 no-print">
            <h3 className="font-display font-bold text-2xl text-slate-900 dark:text-white flex items-center gap-2">
              <GraduationCap className="text-blue-600 dark:text-cyan-400" />
              <span>Academic & General Journey</span>
            </h3>

            <div className="font-sans text-slate-600 dark:text-slate-300 leading-relaxed text-base space-y-4">
              <p>
                I am currently pursuing a <strong>Bachelor of Engineering in Artificial Intelligence and Data Science</strong> at A.C. Patil College of Engineering, Mumbai University. This path defines my aspiration to build next-generation machine learning architectures and data-science solutions.
              </p>
              <p>
                Previously, I completed a <strong>Diploma in Information Technology from Government Polytechnic Thane</strong> with an outstanding academic performance of <strong>89.06%</strong>. This technical foundation gave me exhaustive training in core Software Engineering principles, database designs, administrative computer networks, and modern web application layers.
              </p>
              <p>
                My initial deep tech curiosity sparked during secondary school achievements, securing an impressive <strong>90% score in my Secondary School Certificate (SSC)</strong> board examinations.
              </p>
              <p>
                With cross-functional internships finished successfully under my belt (covering practical Web Development, Cyber Security monitoring, and AI development), I lead with custom leadership traits, analytical critical reasoning, adaptability, and high professional commitment.
              </p>
            </div>

            {/* Print resume quick action banner */}
            <div className="p-5 rounded-2xl glass-panel border border-slate-200/60 dark:border-slate-800/60 bg-slate-50/50 dark:bg-slate-950/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-8" id="resume-download-banner">
              <div>
                <p className="font-display font-bold text-sm text-slate-900 dark:text-white">
                  Looking for a hard copy?
                </p>
                <p className="font-sans text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Format and prepare a professional resume document ready for PDF export.
                </p>
              </div>
              <button
                onClick={handlePrint}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs dark:bg-cyan-500 dark:hover:bg-cyan-600 dark:text-slate-950 flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm hover:shadow active:scale-95"
                id="print-resume_btn"
              >
                <Printer size={14} />
                <span>Print Resume Sheet</span>
              </button>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
