import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Download, Printer, X, ExternalLink, ShieldCheck, Mail, Globe, MapPin, Award } from 'lucide-react';
import { personalInfo, educationList, experienceList, skillCategories, certifications, projectsList } from '../data';

export default function ResumeModal() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handleOpen = () => setIsOpen(true);
    window.addEventListener('open-resume-modal', handleOpen);
    return () => window.removeEventListener('open-resume-modal', handleOpen);
  }, []);

  const handlePrintTrigger = () => {
    const originalTitle = document.title;
    const today = new Date();
    // Format date as YYYY-MM-DD or similar clean format
    const formattedDate = today.toISOString().split('T')[0].replace(/-/g, '_');
    document.title = `Adam_Abdul_Mulani_Resume_${formattedDate}`;
    window.print();
    // Restore original title shortly after
    setTimeout(() => {
      document.title = originalTitle;
    }, 1000);
  };

  const handleOpenNewTab = () => {
    window.open(window.location.origin, '_blank');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-8 overflow-y-auto pointer-events-auto no-print"
          id="resume-dispatcher-modal"
          onClick={() => setIsOpen(false)}
        >
          <motion.div
            initial={{ scale: 0.95, y: 30 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: 30 }}
            transition={{ type: "spring", damping: 25, stiffness: 350 }}
            className="max-w-md w-full bg-slate-900 border border-slate-800 p-6 sm:p-8 rounded-3xl shadow-2xl relative text-left overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Ambient accent background flare */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl" />
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-blue-600/10 rounded-full blur-2xl" />

            <div className="absolute top-5 right-5 z-20">
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-xl bg-slate-950 border border-slate-850 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Title / Description */}
            <div className="flex gap-4 items-start mb-6">
              <div className="p-3 bg-blue-600/15 text-blue-400 dark:text-cyan-400 rounded-2xl shrink-0">
                <FileText size={24} className="animate-pulse" />
              </div>
              <div className="space-y-0.5">
                <h3 className="font-display font-black text-lg tracking-wider text-white uppercase">
                  PDF Resume Generator
                </h3>
                <p className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest font-bold">
                  High-Fidelity Document Builder
                </p>
              </div>
            </div>

            {/* Instruction Notice */}
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-850/80 mb-6 space-y-3 text-xs text-slate-350 font-sans leading-relaxed">
              <div className="flex gap-2 items-center text-cyan-300 font-bold mb-1">
                <ShieldCheck size={14} className="text-cyan-400" />
                <span className="uppercase font-mono text-[10px] tracking-wider">PDF Only Export Allowed</span>
              </div>
              <p>
                To generate a highly polished, single-page professional resume sheet in official <b>PDF format</b>:
              </p>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-400 pl-1">
                <li>Click the <b>&quot;Save / Print to PDF&quot;</b> button below.</li>
                <li>In the browser dialogue, set Destination to <b>&quot;Save as PDF&quot;</b>.</li>
                <li>Turn on <b>&quot;Background graphics&quot;</b> and set Layout to <b>&quot;Portrait&quot;</b>.</li>
              </ul>
              <p className="text-[10px] italic text-slate-500">
                * Note: If you are using a mobile browser, saving as PDF will automatically download the resume to your device files.
              </p>
            </div>

            {/* Single Core Button Action */}
            <div className="space-y-4">
              <button
                onClick={handlePrintTrigger}
                className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-cyan-500 hover:opacity-95 text-white font-mono font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer shadow-lg active:scale-95 transition-all text-center border-none flex items-center justify-center gap-2"
                id="modal-trigger-instant-print"
              >
                <Printer size={14} />
                <span>Save / Print to PDF</span>
              </button>

              <button
                onClick={handleOpenNewTab}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-[11px] uppercase tracking-wider rounded-xl cursor-pointer transition-all text-center border border-slate-750 flex items-center justify-center gap-1.5"
              >
                <ExternalLink size={12} />
                <span>Open in New Tab to Print &gt;</span>
              </button>
            </div>

            {/* Footer coordinates */}
            <div className="pt-4 mt-6 border-t border-slate-850 flex items-center justify-between text-[9px] font-mono text-slate-500 uppercase tracking-widest">
              <span>Verified Dossier Profile</span>
              <span>Active Coordinates</span>
            </div>

          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
