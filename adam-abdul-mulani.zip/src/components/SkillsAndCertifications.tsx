import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Code2, ShieldCheck, Database, Brain, Sparkles, BookOpen, Compass, Clipboard } from 'lucide-react';
import { skillCategories, certifications } from '../data';

export default function SkillsAndCertifications() {
  const [selectedCategory, setSelectedCategory] = useState(skillCategories[0].category);

  const getCategoryIcon = (categoryName: string) => {
    switch (categoryName) {
      case 'Programming Languages':
        return <Code2 size={16} />;
      case 'Artificial Intelligence':
        return <Brain size={16} />;
      case 'Database Technologies':
        return <Database size={16} />;
      case 'Web Technologies':
        return <Compass size={16} />;
      case 'Cyber Security':
        return <ShieldCheck size={16} />;
      case 'Software Engineering':
        return <Clipboard size={16} />;
      case 'Networking':
        return <BookOpen size={16} />;
      default:
        return <Sparkles size={16} />;
    }
  };

  const activeCategoryData = skillCategories.find((cat) => cat.category === selectedCategory) || skillCategories[0];

  return (
    <section id="skills" className="py-24 bg-white dark:bg-slate-900 transition-colors scroll-mt-20">
      <div className="responsive-container">
        
        {/* SECTION HEADER */}
        <div className="text-center max-w-3xl mx-auto mb-16 no-print">
          <h2 className="font-display font-medium text-xs tracking-widest text-blue-600 dark:text-cyan-400 uppercase">
            Competencies
          </h2>
          <p className="mt-2 font-display font-bold text-3xl sm:text-4xl text-slate-900 dark:text-white tracking-tight">
            Professional Skills & Certifications
          </p>
          <div className="mt-4 w-12 h-1 bg-gradient-to-r from-blue-600 to-cyan-500 mx-auto rounded-full" />
        </div>

        {/* SKILLS SECTION: Split Interactive Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mb-24 items-start" id="skills-explorer-panel">
          
          {/* Left Columns: Categories navigator */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="font-display font-bold text-xl text-slate-900 dark:text-white mb-4">
              Skill Domains
            </h3>
            <p className="text-sm font-sans text-slate-500 dark:text-slate-400 pb-2">
              Select an engineering domain below to explore Adam&apos;s technical readiness levels, languages, and specialties.
            </p>
            
            <div className="flex flex-row overflow-x-auto lg:flex-col gap-2 pb-4 lg:pb-0 scrollbar-none snap-x snap-mandatory touch-pan-x items-stretch" id="skill-categories-tabs">
              {skillCategories.map((cat) => {
                const isActive = cat.category === selectedCategory;
                return (
                  <button
                    key={cat.category}
                    onClick={() => setSelectedCategory(cat.category)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all cursor-pointer text-left whitespace-nowrap lg:whitespace-normal flex-shrink-0 border snap-start min-h-[46px] h-auto ${
                      isActive
                        ? 'bg-blue-600 border-blue-600 text-white dark:bg-none dark:border-cyan-500 dark:text-cyan-400 font-semibold shadow-md dark:shadow-none'
                        : 'bg-slate-50 border-slate-200/50 hover:border-slate-300 dark:bg-slate-800/40 dark:border-slate-800 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                    id={`skill-tab-${cat.category.replace(/\s+/g, '-')}`}
                  >
                    <span className={`flex items-center justify-center p-1.5 rounded-lg shrink-0 ${isActive ? 'bg-white/10 dark:bg-cyan-950/40' : 'bg-slate-200/40 dark:bg-slate-800'}`}>
                      {getCategoryIcon(cat.category)}
                    </span>
                    <span className="flex items-center">{cat.category}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Columns: Competency skill bars */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 shadow-xs" id="skills-display-panel">
            <h4 className="font-display font-bold text-lg text-slate-900 dark:text-white mb-6 uppercase tracking-wider font-mono flex items-center gap-2">
              <span className="text-blue-600 dark:text-cyan-400">{getCategoryIcon(activeCategoryData.category)}</span>
              <span>{activeCategoryData.category}</span>
            </h4>

            <div className="space-y-6">
              {activeCategoryData.skills.map((skill) => (
                <div key={skill.name} className="space-y-2" id={`skill-item-${skill.name.replace(/\s+/g, '-')}`}>
                  <div className="flex justify-between items-center text-sm">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 font-sans">{skill.name}</span>
                    <span className="font-mono text-xs font-bold text-blue-600 dark:text-cyan-400">{skill.level}%</span>
                  </div>
                  {/* Progress track */}
                  <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${skill.level}%` }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                      className="h-full rounded-full bg-gradient-to-r from-blue-600 to-indigo-500 dark:from-cyan-500 dark:to-blue-600"
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* AI-themed compliance signature */}
            <div className="mt-8 pt-6 border-t border-slate-200/50 dark:border-slate-800/80 flex items-center gap-2 text-xs text-slate-400 dark:text-slate-500 font-mono italic">
              <Sparkles size={12} className="text-blue-500 dark:text-cyan-400" />
              <span>Evaluated through continuous academic modules, certified challenges, and field internships.</span>
            </div>
          </div>

        </div>

        {/* CERTIFICATIONS DIVISION */}
        <div className="mt-20">
          <div className="flex items-center gap-2 mb-8" id="certifications-division-header">
            <span className="p-2 bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-cyan-400 rounded-xl">
              <Award size={20} />
            </span>
            <h3 className="font-display font-bold text-2xl text-slate-900 dark:text-white">
              Official Certifications & Credentials
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="certifications-grid">
            {certifications.map((cert) => (
              <div
                key={cert.id}
                className="glass-panel border rounded-2xl p-6 relative overflow-hidden group shadow-xs transition-all hover:shadow hover:border-slate-300 dark:hover:border-slate-700"
                id={`cert-card-${cert.id}`}
              >
                {/* Holographic glowing sphere */}
                <div className="absolute -top-10 -right-10 w-24 h-24 bg-blue-500/10 dark:bg-cyan-400/5 rounded-full blur-xl group-hover:scale-125 transition-transform duration-500" />
                
                {/* Credential Seal */}
                <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-cyan-950/40 flex items-center justify-center text-blue-600 dark:text-cyan-400 mb-4 font-mono font-bold text-sm tracking-tight border border-blue-100/50 dark:border-cyan-900/50">
                  AM
                </div>

                <h4 className="font-display font-bold text-sm text-slate-900 dark:text-white leading-snug tracking-tight">
                  {cert.title}
                </h4>

                <p className="font-sans text-xs text-slate-500 dark:text-slate-400 mt-2 font-medium">
                  Issued by: <span className="text-slate-700 dark:text-slate-350">{cert.issuer}</span>
                </p>

                {cert.organizedBy && (
                  <p className="font-sans text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                    Co-organized: {cert.organizedBy}
                  </p>
                )}

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400 dark:text-slate-500">
                  <span>Credential IDVerified</span>
                  <span className="font-bold text-blue-500 dark:text-cyan-400">{cert.year}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
