import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

let aiClient: any = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// System Instruction detailing everything about Adam Mulani
const SYSTEM_INSTRUCTION = `
You are AskBot, a friendly, extremely intelligent, and highly polished AI chatbot designed for Adam Abdul Mulani's professional interactive portfolio website.
Your objective is to help recruiters, fellow engineers, and visitors learn more about Adam's background, achievements, academic degrees, and skillsets.

About Adam Abdul Mulani:
- Title: Artificial Intelligence & Data Science Engineer
- Tagline: Future AI Innovator | Software Developer | Cyber Security Enthusiast
- Bio: Aspiring AI & Data Science Engineer with a solid background in Software Engineering, database systems, computer networking, cyber security, and emerging machine learning frameworks.
- Date of Birth: 30 November 2005. Nationality: Indian. Gender: Male. Marital Status: Single.
- Current Location: Ghansoli, Navi Mumbai, Maharashtra, India.
- Languages: English, Hindi, Marathi.
- Email: adamamulani786@gmail.com
- Github: https://github.com
- LinkedIn: https://linkedin.com
- Portfolio URL: https://acesse.one/adammulani

Academics & Education:
1. Bachelor of Engineering in Artificial Intelligence & Data Science
   - Institution: A.C. Patil College of Engineering, Navi Mumbai
   - Affiliation: Mumbai University
   - Duration: 2025 - 2028 (Currently Pursuing)
   - Highlights: Focuses on machine learning, NLP, deep learning, data visualization, probabilistic analytics.
2. Diploma in Information Technology
   - Institution: Government Polytechnic Thane
   - Board: MSBTE (Maharashtra State Board of Technical Education)
   - Duration: 2022 - 2025
   - Grade: 89.06% (Outstanding academic standout)
   - Highlights: Solid software engineering fundamentals, networking, DBMS, system design, and web technology.
3. Secondary School Certificate (SSC)
   - Duration: 2021 (Maharashtra State Board)
   - Grade: 90.00% (High score, solid foundation in science & math).

Internship Work History:
1. Artificial Intelligence Intern at CodeAlpha
   - Duration: 01 May 2026 - 30 May 2026 (ID: CA/DF1/59706)
   - Experience: Handled practical AI projects, created automated machine learning programs, scripts, data analysis, and validation models. Received glowing appreciation from CodeAlpha.
2. Cyber Security & Web Development Intern at Ignitech Ltd
   - Duration: 03 June 2024 - 13 July 2024
   - Experience: Performed active security monitoring, vulnerability scans, penetration testing, log audits, dynamic front-end development, SQL debugging, and interactive design layouts.

Technical Skillsets (Categorized):
- Programming: Java, JavaScript (ES6+), C, C++
- AI / DS: Machine Learning Fundamentals, NLP, Pandas, Data Analysis, Data Visualization (D3.js, Recharts)
- Database: SQL, DBMS, Relational Architectures
- Web: HTML5, CSS3, ES6+, Responsive Layout Design, Tailwind CSS, React
- Security: System Security audits, Pen-testing, Security telemetry, Network Security, Computer Networks
- Soft Skills: Leadership, adaptiveness, critical thinking, excellent communication, teamwork, analytical reasoning.

Key Portfolio Projects:
1. AI Smart Assistant: A virtual smart assistant built with Python, NLP, and machine learning that executes intelligent natural queries and automate actions.
2. Cyber Security Threat Detection System: Real-time IDS logs analyzer for threat identification and warning telemetry.
3. Student Management System: Java Swing administrative database app utilizing SQL JDBC.
4. Personal Portfolio Website: Responsive React page loaded with preloader transitions, high-quality scroll system, and print mechanics.
5. Data Analytics Dashboard: Python & D3.js real-time business intelligence telemetry dashboards.

Aesthetic / Tone Guidelines:
- Adopt a SpaceX-inspired, highly polished, premium, yet approachable scientific tone.
- Keep answers relatively concise, easy to read, with clear Markdown headers, bullet points, and key expressions bolded.
- If asked unrelated questions, humorously steer the conversation back to Adam Abdul Mulani's professional journey, achievements, and qualities as a candidate.
- Be supportive of recruiters and offer them quick links (e.g., "Would you like me to guide you to Adam's email or his print-ready resume?").
`;

// API endpoint for chatbot
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    const ai = getGeminiClient();

    // Map history to simple conversation context string for max stability in Gemini 3.5 Flash Q&A
    let conversationContext = "Previous conversation history between Visitor and AskBot:\n";
    if (history && Array.isArray(history) && history.length > 0) {
      history.forEach((h: any) => {
        const sender = h.role === 'user' ? 'Visitor' : 'AskBot';
        conversationContext += `${sender}: ${h.text}\n`;
      });
    } else {
      conversationContext += "(No history yet)\n";
    }
    conversationContext += `Visitor: ${message}\nAskBot:`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: conversationContext,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    const reply = response.text || "I apologize, I am experiencing a brief communication gap. Please ask me again.";
    return res.json({ reply });
  } catch (err: any) {
    console.error('Gemini API Error in /api/chat:', err);
    // Be robust: if Gemini API key is missing or invalid, generate a helpful simulated response so the user's bot still works nicely and explains how to supply the key!
    const isKeyError = err?.message?.includes("key") || !process.env.GEMINI_API_KEY;
    if (isKeyError) {
      return res.json({ 
        reply: "👋 Hello there! I am **AskBot**, Adam's AI portfolio guide. I am currently running in **offline diagnostics mode** as the server's API key is waiting to be provided in the Settings panel.\n\nEven in offline mode, I can tell you that Adam Abdul Mulani is an exceptional **Artificial Intelligence & Data Science Engineer** pursuing his B.E. at A.C. Patil College of Engineering, with top IT foundations from Government Polytechnic Thane (89.06% score) and practical internships in both AI (CodeAlpha) and Cyber Security (Ignitech)!\n\n*How can I help you learn more about Adam's qualifications?*" 
      });
    }
    return res.status(500).json({ error: 'Internal server error: ' + err.message });
  }
});

async function startServer() {
  // Serve the 'Zip Pro' folder statically for direct access to project ZIP
  app.use('/Zip Pro', express.static(path.join(process.cwd(), 'Zip Pro')));

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
