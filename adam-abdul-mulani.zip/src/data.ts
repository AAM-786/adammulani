import { Education, Experience, SkillCategory, Certification, Project, Achievement } from './types';

export const personalInfo = {
  name: "Adam Abdul Mulani",
  title: "Artificial Intelligence & Data Science Engineer",
  tagline: "Future AI Innovator | Software Developer | Cyber Security Enthusiast",
  bio: "I am an aspiring Artificial Intelligence and Data Science Engineer with a strong foundation in Information Technology, Cyber Security, Web Development, and Software Engineering. Passionate about solving real-world problems through technology, innovation, and data-driven solutions.",
  aboutDetailed: "I am currently pursuing a Bachelor of Engineering in Artificial Intelligence and Data Science at A.C. Patil College of Engineering, Mumbai University. Previously, I completed a Diploma in Information Technology from Government Polytechnic Thane with an outstanding academic performance of 89.06%. My journey in technology began with strong academic achievements, securing 90% in SSC. Over the years, I have developed expertise in software development, web technologies, database management, computer networking, cyber security, and emerging AI technologies. I am passionate about continuous learning, innovation, leadership, teamwork, and creating technology solutions that positively impact society.",
  dob: "30 November 2005",
  nationality: "Indian",
  gender: "Male",
  maritalStatus: "Single",
  location: "Ghansoli, Navi Mumbai, Maharashtra, India",
  languages: ["English", "Hindi", "Marathi"],
  email: "adamamulani786@gmail.com",
  phone: "+91 00000-00000",
  portfolioUrl: "https://acesse.one/adammulani",
  socials: {
    linkedin: "https://www.linkedin.com/in/adam-mulani-40848b387",
    github: "https://github.com",
    instagram: "https://instagram.com",
    twitter: "https://twitter.com"
  }
};

export const educationList: Education[] = [
  {
    id: "edu-1",
    degree: "B.E. Artificial Intelligence and Data Science",
    institution: "A.C. Patil College of Engineering",
    universityOrBoard: "Mumbai University",
    duration: "2025 – 2028",
    status: "Currently Pursuing",
    description: "Focused on Artificial Intelligence, Machine Learning, Data Science, Deep Learning, Analytics, and Intelligent Systems.",
    highlights: ["Advanced ML Techniques", "Neural Networks & Deep Learning", "Data Mining & Wrangling", "Probabilistic Analytics"]
  },
  {
    id: "edu-2",
    degree: "Diploma in Information Technology",
    institution: "Government Polytechnic Thane",
    universityOrBoard: "MSBTE (Maharashtra State Board of Technical Education)",
    duration: "2022 – 2025",
    percentageOrGpa: "89.06%",
    highlights: [
      "Software Engineering",
      "Database Management Systems",
      "Computer Networks",
      "Web Technologies",
      "System Analysis and Design"
    ]
  },
  {
    id: "edu-3",
    degree: "Secondary School Certificate (SSC)",
    institution: "High School education",
    universityOrBoard: "Maharashtra State Board",
    duration: "2021",
    percentageOrGpa: "90%",
    highlights: ["Secured 90% overall marks", "Outstanding foundation in Science and Mathematics"]
  }
];

export const experienceList: Experience[] = [
  {
    id: "exp-1",
    title: "Artificial Intelligence Intern",
    company: "CodeAlpha",
    duration: "01 May 2026 – 30 May 2026",
    role: "Artificial Intelligence Intern (ID: CA/DF1/59706)",
    responsibilities: [
      "Worked on practical AI-based projects and application implementation",
      "Explored algorithms and models for machine learning and deep learning concepts",
      "Developed intelligent program architectures and automation scripts",
      "Performed detailed data analysis, sanitation, and intelligence tasks",
      "Applied advanced AI frameworks for solving specific, real-world case challenges",
      "Enhanced proficiency in machine learning pipelines and functional debugging"
    ],
    achievements: [
      "Successfully completed virtual internship within rigorous timeline targets",
      "Demonstrated outstanding dedication, proactive learning, and technical execution",
      "Received formal appreciation certificate from the CodeAlpha selection committee"
    ]
  },
  {
    id: "exp-2",
    title: "Cyber Security Intern",
    company: "Ignitech Ltd",
    duration: "03 June 2024 – 13 July 2024",
    role: "Cyber Security & Web Development Intern",
    responsibilities: [
      "Assisted in active security monitoring, system telemetry, and network analysis",
      "Conducted detailed system security assessment protocols and pen-testing checklists",
      "Contributed to dynamic web front-end development, testing, and interface responsive sizing",
      "Supported comprehensive technical design documentation and system security logs",
      "Collaborated constructively with seasoned tech leads and cross-functional team members",
      "Enhanced organizational network topology mapping and security protocol implementations",
      "Troubleshot live web component vulnerabilities and database query errors"
    ],
    achievements: [
      "Successfully completed full 6-week intensive industry internship program",
      "Gained critical real-world cyber security defense exposure and vulnerability tracking",
      "Developed professional peer group interaction and workplace communication experience"
    ]
  }
];

export const skillCategories: SkillCategory[] = [
  {
    category: "Programming Languages",
    skills: [
      { name: "C", level: 85 },
      { name: "C++", level: 80 },
      { name: "Java", level: 88 },
      { name: "JavaScript", level: 90 }
    ]
  },
  {
    category: "Artificial Intelligence",
    skills: [
      { name: "Machine Learning Fundamentals", level: 88 },
      { name: "Data Analysis & Pandas", level: 85 },
      { name: "AI Concepts & NLP", level: 80 },
      { name: "Problem Solving", level: 92 }
    ]
  },
  {
    category: "Database Technologies",
    skills: [
      { name: "SQL (Structured Query Language)", level: 90 },
      { name: "DBMS / Relational Arch", level: 88 }
    ]
  },
  {
    category: "Web Technologies",
    skills: [
      { name: "HTML5 / CSS3", level: 95 },
      { name: "JavaScript ES6+", level: 90 },
      { name: "Responsive Layout Design", level: 92 },
      { name: "Modern Web Development", level: 88 }
    ]
  },
  {
    category: "Cyber Security",
    skills: [
      { name: "Security Assessment", level: 85 },
      { name: "Network Security", level: 82 },
      { name: "Security Monitoring", level: 80 },
      { name: "Cyber Security Fundamentals", level: 86 }
    ]
  },
  {
    category: "Software Engineering",
    skills: [
      { name: "System Analysis & Design", level: 86 },
      { name: "Software Development (SDLC)", level: 88 },
      { name: "Debugging & Diagnostics", level: 85 },
      { name: "Drafting Documentation", level: 90 }
    ]
  },
  {
    category: "Networking",
    skills: [
      { name: "Computer Networks", level: 84 },
      { name: "Network Architecture", level: 80 },
      { name: "Protocols (TCP/IP, DNS, SSL)", level: 85 }
    ]
  },
  {
    category: "Professional Skills",
    skills: [
      { name: "Leadership", level: 90 },
      { name: "Communication", level: 92 },
      { name: "Teamwork & Collaboration", level: 95 },
      { name: "Critical Thinking", level: 90 },
      { name: "Time Management", level: 88 },
      { name: "Adaptability", level: 92 },
      { name: "Professional Ethics", level: 94 },
      { name: "Decision Making", level: 86 },
      { name: "Analytical Thinking", level: 92 }
    ]
  }
];

export const certifications: Certification[] = [
  {
    id: "cert-1",
    title: "Certificate of Internship in Cyber Security",
    issuer: "Ignitech Ltd",
    year: "2024"
  },
  {
    id: "cert-2",
    title: "Artificial Intelligence Internship Certificate",
    issuer: "CodeAlpha",
    year: "2026"
  },
  {
    id: "cert-3",
    title: "Infosys Springboard Certificate",
    issuer: "Infosys Springboard",
    year: "2024"
  },
  {
    id: "cert-4",
    title: "School Challenge Program Certificate",
    issuer: "Agastya Foundation",
    organizedBy: "Agastya Foundation & JP Morgan",
    year: "2021"
  }
];

export const projectsList: Project[] = [
  {
    id: "proj-1",
    title: "AI Smart Assistant",
    technologies: ["Python", "AI", "NLP", "Machine Learning"],
    description: "An AI-powered smart virtual assistant capable of intelligent task execution, natural language interaction, and automated operations.",
    category: "ai",
    githubUrl: "https://github.com/adamamulani786/AI-Smart-Assistant",
    demoUrl: "https://github.com/adamamulani786/AI-Smart-Assistant"
  },
  {
    id: "proj-2",
    title: "Cyber Security Threat Detection System",
    technologies: ["Cyber Security", "Networking", "Python", "IDS Logs"],
    description: "A high-performance system monitoring solution built for active threat identification, logs telemetry, and preventing potential network intrusions.",
    category: "security",
    githubUrl: "https://github.com/adamamulani786/Threat-Detection-System",
    demoUrl: "https://github.com/adamamulani786/Threat-Detection-System"
  },
  {
    id: "proj-3",
    title: "Student Management System",
    technologies: ["Java", "SQL", "Swing", "JDBC"],
    description: "A total academic administrative platform featuring secure database access, enrollment controls, automatic reports, and student grading profiles.",
    category: "web",
    githubUrl: "https://github.com/adamamulani786/Student-Management-System",
    demoUrl: "https://github.com/adamamulani786/Student-Management-System"
  },
  {
    id: "proj-4",
    title: "Personal Portfolio Website",
    technologies: ["HTML", "CSS", "JavaScript", "Tailwind CSS"],
    description: "Modern, fully interactive responsive portfolio showcasing professional qualifications, timelines, skill bars, and achievement trackers.",
    category: "web",
    githubUrl: "https://github.com/adamamulani786/Adam-Mulani-Portfolio",
    demoUrl: "https://github.com/adamamulani786/Adam-Mulani-Portfolio"
  },
  {
    id: "proj-5",
    title: "Data Analytics Dashboard",
    technologies: ["Python", "SQL", "Data Visualization", "D3.js"],
    description: "A stunning, dark/light interactive business intelligence layout rendering custom telemetry charts and statistical models in real-time.",
    category: "ai",
    githubUrl: "https://github.com/adamamulani786/Data-Analytics-Dashboard",
    demoUrl: "https://github.com/adamamulani786/Data-Analytics-Dashboard"
  }
];

export const achievementsList: Achievement[] = [
  { id: "ach-1", title: "SSC Score: 90%", detail: "Outstanding academic milestone in secondary school board examinations." },
  { id: "ach-2", title: "Diploma Score: 89.06%", detail: "Ranked among top performers in Diploma in Information Technology at Government Polytechnic Thane." },
  { id: "ach-3", title: "Cyber Security Internship Completed", detail: "Gained real-world vulnerability tracking and security analytics experience at Ignitech Ltd." },
  { id: "ach-4", title: "Artificial Intelligence Internship Completed", detail: "Completed hands-on machine learning implementations and analytics modeling at CodeAlpha." },
  { id: "ach-5", title: "Active Technology Learner", detail: "Earned multiple specialized career certificates in modern engineering fields." },
  { id: "ach-6", title: "Strong Academic Performance", detail: "Maintained a high GPA and outstanding standing throughout state boards and professional coursework." }
];

export const extracurriculars = [
  {
    id: "extra-1",
    title: "Swachh Bharat Mission Theatrical Performance",
    description: "Actively participated in a theatrical awareness campaign in Navi Mumbai promoting civic cleaning schedules, community hygiene standards, and social welfare responsibility to thousands of spectators."
  }
];
