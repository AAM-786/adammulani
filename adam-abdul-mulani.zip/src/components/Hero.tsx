import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowDown, Cpu, ShieldCheck, Code, Sparkles, ChevronRight, Download } from 'lucide-react';
import { personalInfo } from '../data';
import TextType from './TextType';
import Antigravity from './Antigravity';

interface HeroProps {
  theme?: 'light' | 'dark';
}

export default function Hero({ theme }: HeroProps) {
  const [isDesktopOrLaptop, setIsDesktopOrLaptop] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const checkScreen = () => {
      // Laptop and desktop screens are typically width >= 1024px
      setIsDesktopOrLaptop(window.innerWidth >= 1024);
    };
    checkScreen();
    window.addEventListener('resize', checkScreen);

    // Track user prefers-reduced-motion media query to bypass heavy canvas load
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    const handleMotionChange = (e: MediaQueryListEvent) => {
      setPrefersReducedMotion(e.matches);
    };
    mediaQuery.addEventListener('change', handleMotionChange);

    // Dynamic support for mobile menu open/close tracking to pause/resume Antigravity
    const handleMenuChange = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        setMobileMenuOpen(!!customEvent.detail.open);
      }
    };
    window.addEventListener('mobile-menu-changed', handleMenuChange);

    return () => {
      window.removeEventListener('resize', checkScreen);
      mediaQuery.removeEventListener('change', handleMotionChange);
      window.removeEventListener('mobile-menu-changed', handleMenuChange);
    };
  }, []);

  const handleScroll = (targetId: string) => {
    const el = document.getElementById(targetId);
    if (el) {
      const rect = el.getBoundingClientRect();
      const absoluteTop = rect.top + window.pageYOffset;
      const top = absoluteTop - 80;
      window.scrollTo({
        top,
        behavior: 'smooth',
      });
    }
  };

  // Helper to trigger printable resume
  const handlePrintResume = () => {
    window.dispatchEvent(new CustomEvent('open-resume-modal'));
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 overflow-hidden bg-slate-50 dark:bg-slate-950 transition-colors animate-fade-in"
    >
      {/* Dynamic tech-grid background */}
      <div className="absolute inset-0 z-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] dark:bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-40" />

      {/* Futuristic abstract glowing spots */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 dark:bg-cyan-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 right-1/4 w-[28rem] h-[28rem] bg-indigo-500/10 dark:bg-blue-500/10 rounded-full blur-3xl" />

      {/* Interactive Anti-Gravity Particle Background (R3F) - Rendered ONLY on Desktop and Laptop screens per spec */}
      {isDesktopOrLaptop && !prefersReducedMotion && !mobileMenuOpen && (
        <div className="absolute inset-0 z-0 pointer-events-none md:pointer-events-auto opacity-75">
          <Antigravity
            count={4000}
            magnetRadius={17}
            ringRadius={9}
            waveSpeed={3.7}
            waveAmplitude={4.2}
            particleSize={0.7}
            lerpSpeed={0.13}
            color={theme === 'light' ? '#94a3b8' : '#e8e7e7'}
            autoAnimate={false}
            particleVariance={0.8}
            rotationSpeed={0.5}
            depthFactor={3.9}
            pulseSpeed={5.1}
            particleShape="sphere"
            fieldStrength={17.2}
          />
        </div>
      )}

      {/* Radial Gradient Overlay - Layered at z-[1] to maintain high readability */}
      <div
        className="absolute inset-0 z-[1] pointer-events-none"
        style={{
          background: 'radial-gradient(circle at center, rgba(255, 255, 255, 0.03), transparent 70%)'
        }}
        id="hero-gradient-overlay"
      />

      {/* Animated Floating Nodes (AI Visual Theme) */}
      <div className="absolute inset-0 pointer-events-none z-10 opacity-70">
        <motion.div
          animate={{
            y: [0, -20, 0],
            x: [0, 10, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-[20%] left-[5%] xl:left-[10%] p-3 glass-panel rounded-2xl hidden lg:flex items-center gap-2 max-w-max shadow-sm border border-slate-200 dark:border-slate-800"
        >
          <div className="p-1.5 bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 rounded-lg">
            <Cpu size={16} />
          </div>
          <span className="text-xs font-mono font-medium text-slate-700 dark:text-slate-300">Neural Network</span>
        </motion.div>

        <motion.div
          animate={{
            y: [0, 25, 0],
            x: [0, -15, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1.5
          }}
          className="absolute top-[25%] xl:top-[35%] right-[3%] xl:right-[8%] p-3 glass-panel rounded-2xl hidden lg:flex items-center gap-2 max-w-max shadow-sm border border-slate-200 dark:border-slate-800"
        >
          <div className="p-1.5 bg-cyan-100 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 rounded-lg">
            <ShieldCheck size={16} />
          </div>
          <span className="text-xs font-mono font-medium text-slate-700 dark:text-slate-300">Intrusion Shield</span>
        </motion.div>

        <motion.div
          animate={{
            y: [0, -15, 0],
            x: [0, -20, 0],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 3
          }}
          className="absolute bottom-[25%] left-[5%] xl:left-[15%] p-3 glass-panel rounded-2xl hidden lg:flex items-center gap-2 max-w-max shadow-sm border border-slate-200 dark:border-slate-800"
        >
          <div className="p-1.5 bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 rounded-lg">
            <Code size={16} />
          </div>
          <span className="text-xs font-mono font-medium text-slate-700 dark:text-slate-300">C++ / Java Script</span>
        </motion.div>

        {/* Decorative central connection circles */}
        <div className="absolute top-[55%] right-[20%] hidden lg:block">
          <svg width="240" height="120" viewBox="0 0 240 120" fill="none" className="stroke-slate-300 dark:stroke-slate-800 stroke-2 stroke-dasharray">
            <path d="M10 10 Q 120 110, 230 10" strokeDasharray="5,5" />
            <circle cx="10" cy="10" r="4" className="fill-blue-600 dark:fill-cyan-400" />
            <circle cx="230" cy="10" r="4" className="fill-cyan-500 dark:fill-blue-500" />
          </svg>
        </div>
      </div>

      <div className="relative z-[2] max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-6 pb-16">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 25 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.85, ease: 'easeOut' }}
          className="flex flex-col items-center justify-center p-6 sm:p-10 md:p-16 rounded-[40px] border border-white/80 dark:border-slate-800/80 shadow-[0_30px_70px_-15px_rgba(0,0,0,0.22)] dark:shadow-[0_30px_70px_-15px_rgba(0,0,0,0.65)] bg-white/92 dark:bg-slate-950/92 backdrop-blur-3xl transition-all duration-300 relative overflow-hidden"
        >
          {/* Subtle responsive glowing backlights inside the card */}
          <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-blue-600/10 dark:bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-indigo-500/10 dark:bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

          {/* Sparkles pill introduction */}
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-100/70 dark:bg-blue-950/55 border border-blue-200/50 dark:border-blue-900/40 text-blue-700 dark:text-cyan-400 text-xs font-bold mb-6 tracking-wide uppercase shadow-xs z-10"
            id="hero-intro-pill"
          >
            <Sparkles size={14} className="animate-pulse text-blue-600 dark:text-cyan-400" />
            <span>Engineering Tomorrow&apos;s Intelligence</span>
          </div>

          {/* Primary Name styled with dynamic TextType component and elegant Times New Roman font */}
          <TextType
            id="hero-developer-name"
            text="ADAM ABDUL MULANI"
            as="h1"
            typingSpeed={90}
            pauseDuration={2000}
            showCursor={true}
            cursorCharacter="|"
            className="font-extrabold text-3xl sm:text-5xl md:text-6xl lg:text-7xl text-slate-950 dark:text-white tracking-tight leading-none mb-3 select-none z-10"
            style={{ fontFamily: '"Times New Roman", Times, Georgia, serif', fontWeight: 800 }}
          />

          {/* Dynamic / Styled Title in google Outfit font */}
          <p
            className="mt-3 font-outfit text-lg sm:text-2xl md:text-3xl font-extrabold bg-gradient-to-r from-blue-700 via-indigo-600 to-cyan-500 dark:from-cyan-400 dark:via-blue-500 dark:to-teal-400 bg-clip-text text-transparent z-10"
            id="hero-role-title"
          >
            {personalInfo.title}
          </p>

          {/* Quick Tags / Subheads */}
          <p
            className="mt-2 text-xs sm:text-base text-slate-600 dark:text-slate-300 font-mono tracking-wider font-semibold z-10"
            id="hero-subrole-tagline"
          >
            {personalInfo.tagline}
          </p>

          {/* Short Bio Block */}
          <div className="mt-8 max-w-3xl mx-auto z-10 px-4">
            <p className="text-base sm:text-lg text-slate-800 dark:text-slate-200 font-outfit font-medium leading-relaxed tracking-wide antialiased" id="hero-mini-bio">
              &ldquo;I am an aspiring <span className="text-blue-600 dark:text-cyan-400 font-semibold">Artificial Intelligence and Data Science Engineer</span> with a strong foundation in <span className="text-slate-900 dark:text-white font-semibold">Information Technology</span>, <span className="text-slate-900 dark:text-white font-semibold">Cyber Security</span>, <span className="text-slate-900 dark:text-white font-semibold">Web Development</span>, and <span className="text-slate-900 dark:text-white font-semibold">Software Engineering</span>. Passionate about solving real-world problems through technology, innovation, and data-driven solutions.&rdquo;
            </p>
          </div>

          {/* CTAs / Interactive Action Bars */}
          <div
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 w-full z-10"
            id="hero-actions-container"
          >
            <button
              onClick={() => handleScroll('projects')}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm transition-all duration-300 shadow-md shadow-blue-500/20 hover:shadow-lg dark:bg-cyan-500 dark:hover:bg-cyan-600 dark:text-slate-950 dark:shadow-cyan-400/10 flex items-center justify-center gap-2 cursor-pointer border border-transparent hover:-translate-y-0.5"
              id="hero-btn-projects"
            >
              <span>View Projects</span>
              <ChevronRight size={16} />
            </button>

            <button
              onClick={() => handleScroll('contact')}
              className="w-full sm:w-auto px-8 py-4 rounded-xl glass-panel border border-slate-300 hover:border-slate-400 dark:border-slate-800 dark:hover:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100/50 dark:hover:bg-slate-900/35 font-semibold text-sm transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer hover:-translate-y-0.5"
              id="hero-btn-contact"
            >
              Contact Me
            </button>

            <button
              onClick={handlePrintResume}
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-slate-950 text-slate-50 hover:bg-slate-850 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-slate-200 font-semibold text-sm transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer hover:-translate-y-0.5"
              id="hero-btn-resume"
            >
              <Download size={16} />
              <span>Download Resume</span>
            </button>
          </div>
        </motion.div>

        {/* Scroll helper */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 cursor-pointer no-print"
          onClick={() => handleScroll('about')}
          id="hero-scrolldown-indicator"
        >
          <span className="text-xs font-mono font-medium text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            Scroll Down
          </span>
          <motion.div
            animate={{
              y: [0, 8, 0],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="text-slate-400"
          >
            <ArrowDown size={18} />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
