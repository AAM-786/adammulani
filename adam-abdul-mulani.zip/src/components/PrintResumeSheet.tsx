import { personalInfo, educationList, experienceList, skillCategories, certifications, projectsList } from '../data';
import { Mail, MapPin, Globe, Award, Briefcase, GraduationCap, Cpu, BookOpen } from 'lucide-react';

export default function PrintResumeSheet() {
  return (
    <div className="hidden print:block w-full max-w-4xl mx-auto p-0 bg-white text-slate-900 font-sans leading-[1.3] text-[9.5px]" id="printable-resume-layout">
      {/* 1. Header Contact block - Single page layout */}
      <div className="border-b-2 border-slate-900 pb-2 mb-3 flex justify-between items-start">
        <div className="space-y-0.5">
          <h1 className="text-xl font-black uppercase tracking-tight text-slate-900">{personalInfo.name}</h1>
          <p className="text-blue-600 font-bold text-[10px] tracking-wide uppercase">{personalInfo.title}</p>
          <p className="text-slate-600 text-[9px] max-w-xl font-medium leading-[1.35] mt-0.5">
            {personalInfo.bio}
          </p>
        </div>
        <div className="text-right text-[8.5px] text-slate-600 space-y-0.5 shrink-0 pl-4 font-mono">
          <div className="flex items-center justify-end gap-1 font-semibold text-slate-900">
            <MapPin size={10} className="text-slate-500" />
            <span>{personalInfo.location}</span>
          </div>
          <div className="flex items-center justify-end gap-1">
            <Mail size={10} className="text-slate-500" />
            <a href={`mailto:${personalInfo.email}`} className="hover:underline">{personalInfo.email}</a>
          </div>
          <div className="flex items-center justify-end gap-1">
            <Globe size={10} className="text-slate-500" />
            <a href={personalInfo.portfolioUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">
              {personalInfo.portfolioUrl.replace('https://', '')}
            </a>
          </div>
          <div className="flex items-center justify-end gap-1">
            <span className="text-slate-400 font-sans text-[7.5px] uppercase tracking-wider mr-0.5">LinkedIn:</span>
            <span>linkedin.com/in/adam-mulani-40848b387</span>
          </div>
        </div>
      </div>

      {/* Main Side-by-Side Flexbox Structure */}
      <div className="flex flex-row gap-4 items-start">
        {/* LEFT COLUMN: Experience & Education (W: 58%) */}
        <div className="w-[58%] space-y-3 shrink-0">
          
          {/* SECTION: Professional Internships */}
          <section className="space-y-2">
            <h2 className="text-[10px] font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 flex items-center gap-1.5">
              <Briefcase size={11} className="text-blue-600" />
              <span>Internship Work Experience</span>
            </h2>
            
            <div className="space-y-2">
              {experienceList.map((exp) => (
                <div key={exp.id} className="space-y-0.5 page-break-inside-avoid">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-slate-900 text-[9.5px]">{exp.title}</h3>
                      <p className="text-[8.5px] font-bold text-blue-650">{exp.company}</p>
                    </div>
                    <span className="text-[7.5px] font-mono font-medium text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded shrink-0">
                      {exp.duration}
                    </span>
                  </div>
                  <p className="text-[8px] italic text-slate-500 font-mono -mt-0.5">{exp.role}</p>
                  
                  <ul className="list-disc list-outside space-y-0.5 text-slate-600 text-[8.5px] pl-3 leading-snug">
                    {exp.responsibilities.slice(0, 3).map((resp, i) => (
                      <li key={i}>
                        <span>{resp}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="pt-0.5">
                    <p className="text-[7.5px] font-bold text-emerald-800 uppercase tracking-wider font-mono">
                      Key Highlights:
                    </p>
                    <ul className="list-none space-y-0.2 text-slate-600 text-[8.5px] pl-0.5">
                      {exp.achievements.slice(0, 2).map((ach, idx) => (
                        <li key={idx} className="flex gap-1 items-start leading-tight">
                          <span className="text-emerald-500 font-bold text-[8px] shrink-0">✓</span>
                          <span>{ach}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* SECTION: Academic details */}
          <section className="space-y-2">
            <h2 className="text-[10px] font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 flex items-center gap-1.5">
              <GraduationCap size={12} className="text-blue-600" />
              <span>Educational Qualifications</span>
            </h2>
            
            <div className="space-y-2">
              {educationList.map((edu) => (
                <div key={edu.id} className="space-y-0.5 page-break-inside-avoid">
                  <div className="flex justify-between items-start">
                    <h3 className="font-bold text-slate-900 text-[9.5px] leading-tight">{edu.degree}</h3>
                    <span className="text-[7.5px] font-mono font-medium text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded shrink-0">
                      {edu.duration}
                    </span>
                  </div>
                  <div className="flex justify-between items-baseline text-[8.5px]">
                    <span className="text-slate-700 font-semibold">{edu.institution}</span>
                    <span className="text-slate-500 font-mono text-[8px]">{edu.universityOrBoard}</span>
                  </div>

                  <div className="flex gap-3 text-[8.5px] mt-0.5 leading-none">
                    {edu.percentageOrGpa && (
                      <p className="text-slate-600 font-medium">
                        Score: <span className="font-bold text-blue-700 font-mono">{edu.percentageOrGpa}</span>
                      </p>
                    )}
                    {edu.status && (
                      <p className="text-slate-605 font-medium">
                        Status: <span className="bg-slate-50 border border-slate-200 px-1 py-0.2 rounded font-semibold text-slate-700">{edu.status}</span>
                      </p>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-0.5 pt-1">
                    {edu.highlights.slice(0, 4).map((h) => (
                      <span key={h} className="text-[7.5px] font-mono bg-slate-50 text-slate-600 border border-slate-200/40 px-1 py-0.2 rounded">
                        {h}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

        </div>

        {/* RIGHT COLUMN: Skills & Certifications & Projects (W: 42%) */}
        <div className="w-[42%] space-y-3 border-l border-slate-200 pl-3 shrink-0">
          
          {/* SECTION: Technical Skill Matrices */}
          <section className="space-y-2">
            <h2 className="text-[10px] font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 flex items-center gap-1.5">
              <Cpu size={11} className="text-blue-600" />
              <span>Technical Skills</span>
            </h2>
            
            <div className="space-y-1 text-[8.5px]">
              {skillCategories.map((cat) => (
                <div key={cat.category} className="page-break-inside-avoid">
                  <span className="font-bold text-slate-800 font-mono text-[8px] uppercase tracking-wider block">
                    {cat.category}:
                  </span>
                  <p className="text-slate-600 leading-normal">
                    {cat.skills.map(s => s.name).join(', ')}
                  </p>
                </div>
              ))}
            </div>
          </section>

          {/* SECTION: Selected Portfolio Projects */}
          <section className="space-y-2">
            <h2 className="text-[10px] font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 flex items-center gap-1.5">
              <BookOpen size={11} className="text-blue-600" />
              <span>Key Projects</span>
            </h2>
            
            <div className="space-y-1.5">
              {projectsList.slice(0, 3).map((proj) => (
                <div key={proj.id} className="space-y-0.5 page-break-inside-avoid">
                  <h4 className="font-bold text-slate-900 text-[9px] leading-tight">{proj.title}</h4>
                  <p className="text-[8.5px] text-slate-500 leading-snug">{proj.description}</p>
                  <div className="flex flex-wrap gap-0.5 pt-0.5">
                    {proj.technologies.slice(0, 3).map((t) => (
                      <span key={t} className="text-[7.5px] font-mono bg-blue-50 text-blue-700 px-1 py-0.2 rounded border border-blue-100/50">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* SECTION: Credentials & Certifications */}
          <section className="space-y-2">
            <h2 className="text-[10px] font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-0.5 flex items-center gap-1.5">
              <Award size={11} className="text-blue-600" />
              <span>Certifications</span>
            </h2>
            
            <div className="space-y-1">
              {certifications.slice(0, 4).map((cert) => (
                <div key={cert.id} className="text-[8.5px] leading-tight page-break-inside-avoid">
                  <h4 className="font-bold text-slate-900 leading-none">{cert.title}</h4>
                  <div className="flex justify-between items-baseline text-[7.5px] text-slate-500 pt-0.5">
                    <span>{cert.issuer}</span>
                    <span className="font-mono">{cert.year}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

        </div>
      </div>

      {/* Footer sign off */}
      <div className="mt-3 pt-2 border-t border-slate-200 text-center text-[7.5px] text-slate-400 font-mono uppercase tracking-widest leading-none">
        Generated via Adam Abdul Mulani Portfolio &mdash; Established with AI &amp; Data Science Precision
      </div>
    </div>
  );
}
